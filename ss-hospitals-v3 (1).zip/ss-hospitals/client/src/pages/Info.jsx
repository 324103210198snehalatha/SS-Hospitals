import { useEffect, useState } from 'react';
import { Link, useSearchParams } from 'react-router-dom';
import { MapPin, Phone, Siren, Clock, BedDouble, Home as HomeIcon, X } from 'lucide-react';
import useFetch from '../hooks/useFetch';
import api, { errMsg } from '../services/api';
import { Loader, ErrorBox, PageHead, Empty, Tabs, today } from '../components/UI';
import { ABOUT, STATS } from '../data/content';

export function About() {
  return (<>
    <PageHead crumb="About Us" title="About SS Hospitals" sub="Compassionate multispeciality care since 2007" />
    <section className="container section"><div className="two-col">
      <div>
        <span className="eyebrow">Our story</span><h2 style={{ marginTop: 0 }}>A promise made in 2007</h2>
        <div className="story">{ABOUT.story.map((p, i) => <p key={i}>{p}</p>)}</div>
        <div className="quote" style={{ margin: '26px 0' }}>“Treat every patient the way you would want your own family treated.”<div className="muted" style={{ marginTop: 6 }}>— Founders’ guiding principle</div></div>
        <h3>Our founders</h3>
        <div className="grid wide">{['S Sai Sivani', 'S. Sneha Latha Reddy'].map((n) => <div key={n} className="card pad"><h3 style={{ margin: 0 }}>{n}</h3><span className="tag" style={{ margin: '6px 0' }}>Co-founder</span><p className="muted">Founded SS Hospitals in 2007 and continues to guide its patient-first culture. (Add verified biography, qualifications and awards here.)</p></div>)}</div>
        <h3 style={{ marginTop: 30 }}>Our values</h3>
        <div className="grid wide">{ABOUT.values.map(([t, d]) => <div className="card pad" key={t}><h3>{t}</h3><p className="muted">{d}</p></div>)}</div>
      </div>
      <aside className="sticky" style={{ display: 'grid', gap: 16 }}>
        <div className="card pad"><h3>Our mission</h3><p>{ABOUT.mission}</p><h3>Our vision</h3><p>{ABOUT.vision}</p></div>
        <div className="card pad"><h3>Our journey</h3><div className="timeline">{ABOUT.timeline.map(([y, t]) => <div key={y}><b>{y}</b><div className="muted">{t}</div></div>)}</div></div>
      </aside>
    </div><p className="note" style={{ marginTop: 22 }}>{ABOUT.note}</p></section>
    <section className="stats2"><div className="container grid">{STATS.map(([n, l]) => <div key={l}><b>{n}</b><span>{l}</span></div>)}</div></section>
    <section className="container section" style={{ textAlign: 'center' }}><h2>Experience the SS Hospitals difference</h2><Link className="btn btn-lg" to="/book">Book an Appointment</Link></section>
  </>);
}

export function Hospitals() {
  const { data, loading, error } = useFetch('/branches'); const [sp] = useSearchParams(); const [state, setState] = useState('all');
  const city = sp.get('city');
  const list = (data || []).filter((b) => (state === 'all' || b.state === state) && (!city || b.city === city));
  const states = [...new Set((data || []).map((b) => b.state))];
  return (<><PageHead crumb="Hospitals" title="Our Hospitals" sub={`${(data || []).length} branches across ${states.length} states — find the one nearest to you`} /><section className="container section">
    {loading ? <Loader /> : <><ErrorBox msg={error} />
      <Tabs items={[['all', `All (${(data || []).length})`], ...states.map((s) => [s, s])]} value={state} onChange={setState} />
      {city && <p className="muted">Showing {city}. <Link to="/hospitals">Show all</Link></p>}
      {!list.length ? <Empty /> : <div className="grid wide">{list.map((b) => <div key={b._id} className="card pad" style={{ display: 'grid', gap: 10 }}>
        <div style={{ display: 'flex', justifyContent: 'space-between', gap: 8 }}><h3 style={{ margin: 0 }}>{b.city}</h3>{b.isMain && <span className="tag">Main hospital</span>}</div>
        <b style={{ fontSize: 14 }}>{b.name}</b>
        <div className="meta-line"><span><BedDouble size={14} style={{ verticalAlign: -2 }} /> {b.beds} beds</span><span><MapPin size={14} style={{ verticalAlign: -2 }} /> {b.state}</span></div>
        <p className="muted" style={{ margin: 0 }}>{b.address}</p>
        <div className="chips">{(b.highlights || []).map((h) => <span className="chip" key={h}>{h}</span>)}</div>
        <div style={{ fontSize: 14 }}><div><Clock size={13} style={{ verticalAlign: -2 }} /> {b.timings}</div><div><Phone size={13} style={{ verticalAlign: -2 }} /> {b.phone}</div><div><Siren size={13} style={{ verticalAlign: -2 }} /> Emergency: {b.emergencyPhone}</div></div>
        <div className="actions"><Link className="btn btn-sm" to={`/doctors?branch=${b._id}`}>Doctors here</Link><a className="btn btn-sm btn-outline" target="_blank" rel="noreferrer" href={`https://www.google.com/maps/search/?api=1&query=${encodeURIComponent(b.name + ' ' + b.address)}`}>Directions</a></div>
      </div>)}</div>}</>}
  </section></>);
}

const CAT_LABEL = { all: 'All packages', General: 'General', Men: 'Men', Women: 'Women', Senior: 'Senior citizens', Cardiac: 'Heart', Diabetes: 'Diabetes', Child: 'Children' };
function PackageModal({ pkg, onClose }) {
  const [f, setF] = useState({ name: '', phone: '', email: '', date: '' }); const [err, setErr] = useState(''); const [ok, setOk] = useState(false); const [busy, setBusy] = useState(false);
  const submit = async (e) => {
    e.preventDefault(); setErr('');
    if (!f.name.trim()) return setErr('Enter your name');
    if (!/^[6-9]\d{9}$/.test(f.phone)) return setErr('Enter a valid 10-digit mobile number');
    if (f.email && !/^\S+@\S+\.\S+$/.test(f.email)) return setErr('Enter a valid email');
    setBusy(true);
    try { await api.post('/inquiries', { type: 'package', name: f.name, phone: f.phone, email: f.email, message: `Package: ${pkg.name} (₹${pkg.price}). Preferred date: ${f.date || 'any'}` }); setOk(true); } catch (x) { setErr(errMsg(x)); } finally { setBusy(false); }
  };
  return (<div className="modal" onClick={onClose}><div className="card" onClick={(e) => e.stopPropagation()}>
    <div className="toolbar"><h3 style={{ margin: 0 }}>Book: {pkg.name}</h3><button className="btn btn-sm btn-outline" onClick={onClose} aria-label="Close"><X size={14} /></button></div>
    {ok ? <><div className="ok">Request received. Our health-check desk will call you to confirm your slot.</div><p><button className="btn" onClick={onClose}>Done</button></p></> :
      <form className="stack" onSubmit={submit}>
        <p className="muted" style={{ margin: 0 }}>₹{pkg.price} • Fasting: {pkg.fasting} • Report: {pkg.reportTime}</p>
        <input placeholder="Full name" value={f.name} onChange={(e) => setF({ ...f, name: e.target.value })} />
        <div className="two"><input placeholder="Mobile (10 digits)" value={f.phone} onChange={(e) => setF({ ...f, phone: e.target.value })} /><input placeholder="Email (optional)" value={f.email} onChange={(e) => setF({ ...f, email: e.target.value })} /></div>
        <label className="l">Preferred date<input type="date" min={today()} value={f.date} onChange={(e) => setF({ ...f, date: e.target.value })} /></label>
        <ErrorBox msg={err} /><button className="btn" disabled={busy}>{busy ? 'Sending…' : 'Request booking'}</button></form>}
  </div></div>);
}
export function HealthCheckup() {
  const { data, loading, error } = useFetch('/packages'); const [sp] = useSearchParams();
  const [cat, setCat] = useState('all'); const [open, setOpen] = useState(null); const [book, setBook] = useState(null);
  useEffect(() => { const id = sp.get('book'); if (id && data) setBook(data.find((p) => p._id === id) || null); }, [data]); // eslint-disable-line
  const cats = ['all', ...new Set((data || []).map((p) => p.category).filter(Boolean))];
  const list = (data || []).filter((p) => cat === 'all' || p.category === cat);
  return (<><PageHead crumb="Health Check-up" title="Preventive Health Check-ups" sub="Choose a package for you or your family — sample packages and prices" /><section className="container section">
    <div className="grid" style={{ marginBottom: 26 }}>{[['Same-day reports', 'Most results the same day'], ['Home sample collection', 'On selected packages'], ['Doctor consultation', 'Included in most packages'], ['Digital reports', 'In your patient portal']].map(([t, d]) => <div key={t} className="card feature"><span className="ico t"><HomeIcon size={20} /></span><div><h4>{t}</h4><p>{d}</p></div></div>)}</div>
    {loading ? <Loader /> : <><ErrorBox msg={error} />
      <Tabs items={cats.map((c) => [c, CAT_LABEL[c] || c])} value={cat} onChange={setCat} />
      <div className="grid wide">{list.map((p) => <div key={p._id} className="card pkg">{p.popular && <span className="ribbon">Most popular</span>}
        <span className="tag" style={{ width: 'fit-content' }}>{CAT_LABEL[p.category] || p.category}</span><h3 style={{ margin: 0 }}>{p.name}</h3><span className="muted">For: {p.suitableFor}</span>
        <div><span className="price">₹{p.price}</span>{p.originalPrice && <><s>₹{p.originalPrice}</s> <span className="save">Save ₹{p.originalPrice - p.price}</span></>}</div>
        <div className="meta-line"><span>🧪 {p.tests.length} tests</span><span>⏱ {p.reportTime}</span><span>🍽 Fasting: {p.fasting}</span>{p.homeCollection && <span>🏠 Home collection</span>}</div>
        {open === p._id && <ul>{p.tests.map((t) => <li key={t}>{t}</li>)}</ul>}
        <div className="actions"><button className="btn btn-sm btn-outline" onClick={() => setOpen(open === p._id ? null : p._id)}>{open === p._id ? 'Hide tests' : 'View included tests'}</button><button className="btn btn-sm" onClick={() => setBook(p)}>Book now</button></div>
      </div>)}</div></>}
    <div className="two-col" style={{ marginTop: 34 }}>
      <div className="card pad"><h3>Before your check-up</h3><ul className="ul-check"><li>Fast for the hours mentioned (water is allowed)</li><li>Take regular medicines unless your doctor advises otherwise</li><li>Carry a photo ID and previous reports</li><li>Wear comfortable clothing</li><li>Women: avoid scheduling during periods for urine/Pap tests</li></ul></div>
      <div className="card pad"><h3>Need a custom package?</h3><p className="muted">Tell us your age, history and concerns, and our team will suggest the right tests.</p><Link className="btn" to="/contact">Talk to us</Link></div>
    </div>
  </section>{book && <PackageModal pkg={book} onClose={() => setBook(null)} />}</>);
}

export function Contact() {
  const [sp] = useSearchParams(); const pkg = sp.get('package'); const br = useFetch('/branches');
  const [f, setF] = useState({ name: '', email: '', phone: '', message: pkg ? `I would like to book the "${pkg}" health check-up.` : '' });
  const [err, setErr] = useState(''); const [ok, setOk] = useState(false);
  const set = (k) => (e) => setF({ ...f, [k]: e.target.value });
  const submit = async (e) => {
    e.preventDefault(); setErr(''); setOk(false);
    if (!f.name.trim() || !f.message.trim()) return setErr('Name and message are required');
    if (f.email && !/^\S+@\S+\.\S+$/.test(f.email)) return setErr('Enter a valid email');
    try { await api.post('/inquiries', { type: 'contact', ...f }); setOk(true); setF({ name: '', email: '', phone: '', message: '' }); } catch (x) { setErr(errMsg(x)); }
  };
  return (<><PageHead crumb="Contact" title="Contact Us" sub="Emergency: 108 • We respond within one working day" /><section className="container section"><div className="two-col" style={{ gridTemplateColumns: '1fr 1fr' }}>
    <div className="card pad"><h3>Send us a message</h3><form className="stack" onSubmit={submit}><input placeholder="Your name" value={f.name} onChange={set('name')} /><div className="two"><input placeholder="Email" value={f.email} onChange={set('email')} /><input placeholder="Phone" value={f.phone} onChange={set('phone')} /></div>
      <textarea rows="5" placeholder="Message" value={f.message} onChange={set('message')} />{err && <div className="error">{err}</div>}{ok && <div className="ok">Message sent. We will contact you soon.</div>}<button className="btn">Send</button></form></div>
    <div style={{ display: 'grid', gap: 12 }}><div className="card pad" style={{ background: '#fef3f2', borderColor: '#fecdca' }}><h3 style={{ color: '#b42318' }}><Siren size={18} style={{ verticalAlign: -3 }} /> Emergency</h3><p>Call <b>108</b> or go to the emergency department of any branch — open 24x7.</p></div>
      <div className="card pad"><h3>Branch phone numbers</h3><table className="tbl"><tbody>{(br.data || []).map((b) => <tr key={b._id}><td>{b.city}</td><td>{b.phone}</td></tr>)}</tbody></table></div></div>
  </div></section></>);
}
