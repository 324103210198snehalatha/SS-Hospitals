import { useState } from 'react';
import useFetch from '../hooks/useFetch';
import api, { errMsg } from '../services/api';
import { Loader, ErrorBox, Empty, Status } from '../components/UI';
import { Donut } from '../components/Charts';

export function AdminHome() {
  const { data, loading, error } = useFetch('/admin/stats');
  if (loading) return <Loader />;
  if (!data) return <ErrorBox msg={error} />;
  const max = Math.max(1, ...data.perDay.map((d) => d.count));
  return (<div><h2>Dashboard</h2><div className="kpis">{[['Patients', data.patients], ['Doctors', data.doctors], ['Appointments', data.appointments], ['Departments', data.departments]].map(([l, v]) => <div key={l} className="card kpi"><b>{v}</b>{l}</div>)}</div>
    <div className="card pad"><h3>Appointments by date (latest 14 days with bookings)</h3>{!data.perDay.length ? <Empty text="No appointments yet." /> : <div className="bars" style={{ marginBottom: 26 }}>{data.perDay.map((d) => <div key={d._id} title={`${d._id}: ${d.count}`} style={{ height: `${(d.count / max) * 100}%` }}><span>{d._id.slice(5)}</span></div>)}</div>}</div>
    <div className="card pad" style={{ marginTop: 16 }}><h3>By status</h3><Donut parts={data.byStatus.map((s) => ({ label: s._id, value: s.count, color: ({ pending: '#f79009', accepted: '#14a39a', in_consultation: '#7a5af8', completed: '#12b76a', rejected: '#f04438', cancelled: '#98a2b3', no_show: '#667085' })[s._id] || '#0b6b57' }))} /></div></div>);
}
export function AdminAppointments() {
  const { data, loading, error, reload } = useFetch('/admin/appointments'); const [err, setErr] = useState('');
  const act = async (fn) => { try { await fn(); reload(); } catch (e) { setErr(errMsg(e)); } };
  if (loading) return <Loader />;
  return (<div><h2>Appointments</h2><ErrorBox msg={error || err} />{!data?.length ? <Empty /> : <div className="card scroll"><table className="tbl"><thead><tr><th>Patient</th><th>Doctor</th><th>Date</th><th>Time</th><th>Token</th><th>Status</th><th /></tr></thead><tbody>
    {data.map((a) => <tr key={a._id}><td>{a.patientName}<br /><span className="muted">{a.patient?.email}</span></td><td>{a.doctor?.name}</td><td>{a.date}</td><td>{a.slot}</td><td>{a.token ? `#${a.token}` : '—'}</td>
      <td><select value={a.status} onChange={(e) => act(() => api.put(`/appointments/${a._id}/status`, { status: e.target.value }))}>{['pending', 'accepted', 'in_consultation', 'completed', 'rejected', 'cancelled', 'no_show'].map((x) => <option key={x}>{x}</option>)}</select></td>
      <td><button className="btn btn-sm btn-danger" onClick={() => confirm('Delete appointment?') && act(() => api.delete(`/admin/appointments/${a._id}`))}>Delete</button></td></tr>)}</tbody></table></div>}</div>);
}
export function AdminPatients() {
  const { data, loading, error, reload } = useFetch('/admin/patients'); const [err, setErr] = useState('');
  const del = async (id) => { if (!confirm('Delete this patient account?')) return; try { await api.delete(`/admin/users/${id}`); reload(); } catch (e) { setErr(errMsg(e)); } };
  if (loading) return <Loader />;
  return (<div><h2>Patients</h2><ErrorBox msg={error || err} />{!data?.length ? <Empty /> : <div className="card scroll"><table className="tbl"><thead><tr><th>Name</th><th>Email</th><th>Phone</th><th>Joined</th><th /></tr></thead><tbody>
    {data.map((p) => <tr key={p._id}><td>{p.name}</td><td>{p.email}</td><td>{p.phone}</td><td>{new Date(p.createdAt).toLocaleDateString()}</td><td><button className="btn btn-sm btn-danger" onClick={() => del(p._id)}>Delete</button></td></tr>)}</tbody></table></div>}</div>);
}
export function AdminInquiries() {
  const { data, loading, error } = useFetch('/admin/inquiries');
  if (loading) return <Loader />;
  return (<div><h2>Messages & Newsletter</h2><ErrorBox msg={error} />{!data?.length ? <Empty /> : <div className="card scroll"><table className="tbl"><thead><tr><th>Type</th><th>Name</th><th>Email</th><th>Phone</th><th>Message</th></tr></thead><tbody>{data.map((i) => <tr key={i._id}><td>{i.type}</td><td>{i.name}</td><td>{i.email}</td><td>{i.phone}</td><td>{i.message}</td></tr>)}</tbody></table></div>}</div>);
}

const slugify = (s = '') => s.toLowerCase().replace(/[^a-z0-9]+/g, '-').replace(/(^-|-$)/g, '');
function SelectField({ f, value, onChange }) {
  const { data } = useFetch(f.from);
  return <select value={value} onChange={onChange}><option value="">{f.label}</option>{(data || []).map((o) => <option key={o._id} value={o._id}>{o[f.optLabel || 'name']}</option>)}</select>;
}
// Generic add / edit / delete table for admin-managed records
export function AdminCrud({ title, endpoint, fields, columns }) {
  const { data, loading, error, reload } = useFetch(endpoint); const [form, setForm] = useState(null); const [err, setErr] = useState(''); const [busy, setBusy] = useState(false);
  const init = (row) => Object.fromEntries(fields.map((f) => { let v = row?.[f.key]; if (v && typeof v === 'object' && !Array.isArray(v)) v = v._id; if (Array.isArray(v)) v = v.join(', '); return [f.key, v ?? '']; }));
  const open = (row) => { setErr(''); setForm({ id: row?._id, v: init(row) }); };
  const save = async (e) => {
    e.preventDefault(); setErr('');
    const body = {};
    for (const f of fields) {
      if (f.createOnly && form.id) continue;
      let v = form.v[f.key];
      if (f.required && !String(v).trim()) return setErr(`${f.label} is required`);
      if (f.type === 'number') v = v === '' ? undefined : Number(v);
      if (f.type === 'list') v = String(v).split(',').map((x) => x.trim()).filter(Boolean);
      body[f.key] = v;
    }
    if ('slug' in body && !body.slug) body.slug = slugify(body.name || body.title);
    setBusy(true);
    try { form.id ? await api.put(`${endpoint}/${form.id}`, body) : await api.post(endpoint, body); setForm(null); reload(); } catch (x) { setErr(errMsg(x)); } finally { setBusy(false); }
  };
  const del = async (id) => { if (!confirm('Delete this record?')) return; try { await api.delete(`${endpoint}/${id}`); reload(); } catch (x) { alert(errMsg(x)); } };
  const set = (k) => (e) => setForm({ ...form, v: { ...form.v, [k]: e.target.value } });
  if (loading) return <Loader />;
  return (<div><div className="toolbar"><h2>{title}</h2><button className="btn btn-sm" onClick={() => open()}>+ Add</button></div><ErrorBox msg={error} />
    {!data?.length ? <Empty /> : <div className="card scroll"><table className="tbl"><thead><tr>{columns.map(([l]) => <th key={l}>{l}</th>)}<th /></tr></thead><tbody>{data.map((r) => <tr key={r._id}>{columns.map(([l, get]) => <td key={l}>{get(r)}</td>)}
      <td style={{ whiteSpace: 'nowrap' }}><button className="btn btn-sm btn-outline" onClick={() => open(r)}>Edit</button> <button className="btn btn-sm btn-danger" onClick={() => del(r._id)}>Delete</button></td></tr>)}</tbody></table></div>}
    {form && <div className="modal"><div className="card"><form className="stack" onSubmit={save}><h3>{form.id ? 'Edit' : 'Add'} {title}</h3>
      {fields.filter((f) => !(f.createOnly && form.id)).map((f) => <label className="l" key={f.key}>{f.label}{f.required && ' *'}
        {f.type === 'select' ? <SelectField f={f} value={form.v[f.key]} onChange={set(f.key)} /> : f.type === 'textarea' ? <textarea rows="3" value={form.v[f.key]} onChange={set(f.key)} /> : <input type={f.type === 'number' ? 'number' : f.key === 'password' ? 'password' : 'text'} placeholder={f.type === 'list' ? 'comma separated' : ''} value={form.v[f.key]} onChange={set(f.key)} />}</label>)}
      <ErrorBox msg={err} /><div className="actions"><button className="btn" disabled={busy}>{busy ? 'Saving…' : 'Save'}</button><button type="button" className="btn btn-outline" onClick={() => setForm(null)}>Cancel</button></div></form></div></div>}</div>);
}
const F = (key, label, extra = {}) => ({ key, label, ...extra });
export const ADMIN_RESOURCES = {
  doctors: { title: 'Doctors', endpoint: '/doctors', columns: [['Name', (r) => r.name], ['Speciality', (r) => r.speciality?.name], ['Department', (r) => r.department?.name], ['Experience', (r) => `${r.experience} yrs`]],
    fields: [F('name', 'Name', { required: true }), F('email', 'Login email', { required: true, createOnly: true }), F('password', 'Password (default Doctor@123)', { createOnly: true }), F('qualification', 'Qualification'), F('designation', 'Designation'), F('gender', 'Gender (M / F)'), F('languages', 'Languages', { type: 'list' }), F('expertise', 'Areas of expertise', { type: 'list' }), F('education', 'Education', { type: 'list' }), F('experience', 'Experience (years)', { type: 'number' }), F('fee', 'Fee (₹)', { type: 'number' }),
      F('department', 'Department', { type: 'select', from: '/departments', required: true }), F('speciality', 'Speciality', { type: 'select', from: '/specialities', required: true }), F('branch', 'Branch', { type: 'select', from: '/branches', optLabel: 'name' }), F('bio', 'Bio', { type: 'textarea' })] },
  departments: { title: 'Departments', endpoint: '/departments', columns: [['Name', (r) => r.name], ['Description', (r) => r.description]], fields: [F('name', 'Name', { required: true }), F('description', 'Description', { type: 'textarea' })] },
  specialities: { title: 'Specialities', endpoint: '/specialities', columns: [['Name', (r) => r.name], ['Department', (r) => r.department?.name]],
    fields: [F('name', 'Name', { required: true }), F('slug', 'Slug (auto if empty)'), F('intro', 'Introduction', { type: 'textarea' }), F('treatments', 'Treatments', { type: 'list' }), F('conditions', 'Conditions treated', { type: 'list' }), F('facilities', 'Facilities', { type: 'list' }), F('department', 'Department', { type: 'select', from: '/departments' })] },
  services: { title: 'Healthcare Services', endpoint: '/services', columns: [['Title', (r) => r.title], ['Summary', (r) => r.summary]], fields: [F('title', 'Title', { required: true }), F('slug', 'Slug (auto if empty)'), F('summary', 'Summary'), F('details', 'Details', { type: 'textarea' })] },
  packages: { title: 'Health-check Packages', endpoint: '/packages', columns: [['Name', (r) => r.name], ['Price', (r) => `₹${r.price}`], ['Tests', (r) => r.tests?.length]], fields: [F('name', 'Name', { required: true }), F('price', 'Price (₹)', { type: 'number', required: true }), F('category', 'Category (General, Men, Women, Senior, Cardiac, Diabetes, Child)'), F('originalPrice', 'Original price (₹)', { type: 'number' }), F('fasting', 'Fasting'), F('reportTime', 'Report time'), F('suitableFor', 'Suitable for'), F('tests', 'Tests', { type: 'list' }), F('description', 'Description', { type: 'textarea' })] },
  branches: { title: 'Hospital Locations', endpoint: '/branches', columns: [['Name', (r) => r.name], ['City', (r) => r.city], ['State', (r) => r.state], ['Phone', (r) => r.phone]], fields: [F('name', 'Name', { required: true }), F('city', 'City', { required: true }), F('state', 'State', { required: true }), F('address', 'Address'), F('phone', 'Phone'), F('emergencyPhone', 'Emergency phone'), F('beds', 'Beds', { type: 'number' }), F('timings', 'Timings'), F('highlights', 'Highlights', { type: 'list' })] },
};
