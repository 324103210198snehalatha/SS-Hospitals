import { useState } from 'react';
import { Link, Navigate, useNavigate, useLocation, useParams } from 'react-router-dom';
import { UserRound, Stethoscope, ShieldCheck, Eye, EyeOff, LogOut, Wand2 } from 'lucide-react';
import { useAuth, dashboardPath } from '../context/AuthContext';
import { errMsg } from '../services/api';

const ROLES = {
  patient: { label: 'Patient', icon: UserRound, art: 'art-patient', head: 'Welcome back', pts: ['Book appointments online', 'Get your token & estimated time', 'See your queue status live', 'Access records & prescriptions'], demo: 'patient@sshospitals.test / Patient@123', cred: ['patient@sshospitals.test', 'Patient@123'] },
  doctor: { label: 'Doctor', icon: Stethoscope, art: 'art-doctor', head: 'Doctor desk', pts: ['Accept or reject appointment requests', 'Manage today’s patient queue', 'Write consultation notes & prescriptions', 'Track patients, completions and trends'], demo: 'doctor1@sshospitals.test / Doctor@123', cred: ['doctor1@sshospitals.test', 'Doctor@123'] },
  admin: { label: 'Admin', icon: ShieldCheck, art: 'art-admin', head: 'Hospital admin', pts: ['Manage doctors, departments & branches', 'Monitor appointments & patients', 'Manage packages & services', 'Read patient enquiries'], demo: 'admin@sshospitals.test / Admin@123', cred: ['admin@sshospitals.test', 'Admin@123'] },
};

export function LoginChooser() {
  const { user } = useAuth();
  if (user) return <Navigate to={dashboardPath(user.role)} replace />;
  return (<section className="container section" style={{ maxWidth: 900 }}>
    <div style={{ textAlign: 'center', marginBottom: 26 }}><span className="eyebrow">Login</span><h1 style={{ margin: '0 0 6px' }}>Choose your portal</h1><p className="muted">Patients and doctors have separate logins.</p></div>
    <div className="portal-pick">{Object.entries(ROLES).map(([k, r]) => { const I = r.icon; return <Link key={k} to={`/login/${k}`} className="card"><span className="ico" style={{ width: 64, height: 64 }}><I size={30} /></span><h3 style={{ margin: 0 }}>{r.label} Login</h3><span className="muted">{r.head}</span></Link>; })}</div>
    <p className="muted" style={{ textAlign: 'center', marginTop: 22 }}>New patient? <Link to="/register">Create an account</Link></p>
  </section>);
}

// Only go back to the page the user came from if it is not another role's portal.
const safeTarget = (from, u) => {
  const own = dashboardPath(u.role);
  if (!from) return own;
  const portal = ['/admin', '/doctor', '/patient'].find((p) => from === p || from.startsWith(p + '/'));
  return !portal || portal === own ? from : own;
};

export function Login() {
  const { role } = useParams(); const r = ROLES[role];
  const { user, login, logout } = useAuth(); const nav = useNavigate(); const loc = useLocation();
  const [f, setF] = useState({ email: '', password: '' }); const [err, setErr] = useState(''); const [busy, setBusy] = useState(false); const [show, setShow] = useState(false);
  if (!r) return <Navigate to="/login" replace />;
  if (user && user.role === role) return <Navigate to={safeTarget(loc.state?.from, user)} replace />;
  const I = r.icon;
  const submit = async (e) => {
    e.preventDefault(); setErr('');
    const email = f.email.trim().toLowerCase();
    if (!email || !f.password) return setErr('Enter email and password');
    setBusy(true);
    try { const u = await login(email, f.password, role); nav(safeTarget(loc.state?.from, u), { replace: true }); }
    catch (x) { setErr(errMsg(x)); } finally { setBusy(false); }
  };
  return (<div className="container"><div className="auth-split">
    <div className={`side-art ${r.art}`}><I size={44} /><h2>{r.label} Login</h2><p style={{ opacity: .9, margin: 0 }}>{r.head}</p><ul className="ul-check" style={{ color: '#fff' }}>{r.pts.map((p) => <li key={p}>{p}</li>)}</ul></div>
    <div className="form">
      <div className="switch">{Object.entries(ROLES).map(([k, v]) => <Link key={k} to={`/login/${k}`} className={k === role ? 'on' : ''}>{v.label}</Link>)}</div>
      {user ? (<>
        <h2 style={{ margin: '8px 0 0' }}>You are already signed in</h2>
        <div className="note">Signed in as <b>{user.name}</b> ({user.role}). To use the <b>{r.label.toLowerCase()}</b> login, please log out of this account first.</div>
        <div className="actions"><button className="btn" onClick={logout}><LogOut size={16} style={{ verticalAlign: -3 }} /> Log out &amp; continue</button><Link className="btn btn-outline" to={dashboardPath(user.role)}>Go to my dashboard</Link></div>
      </>) : (<>
        <h2 style={{ margin: '8px 0 0' }}>Sign in as {r.label.toLowerCase()}</h2>
        <form onSubmit={submit} noValidate>
          <input type="email" placeholder="Email" autoComplete="username" autoCapitalize="none" autoCorrect="off" spellCheck="false" value={f.email} onChange={(e) => setF({ ...f, email: e.target.value })} />
          <div className="pw"><input type={show ? 'text' : 'password'} placeholder="Password" autoComplete="current-password" value={f.password} onChange={(e) => setF({ ...f, password: e.target.value })} />
            <button type="button" className="pw-eye" aria-label={show ? 'Hide password' : 'Show password'} onClick={() => setShow(!show)}>{show ? <EyeOff size={18} /> : <Eye size={18} />}</button></div>
          {err && <div className="error" role="alert">{err}</div>}
          <button className="btn" disabled={busy}>{busy ? 'Signing in…' : `Login as ${r.label}`}</button>
        </form>
        {role === 'patient' && <p className="muted">New patient? <Link to="/register">Register</Link></p>}
        {role === 'doctor' && <p className="muted">Doctor accounts are created by the hospital admin.</p>}
        <p className="muted" style={{ fontSize: 12 }}>Demo account: {r.demo} <button type="button" className="linkbtn" onClick={() => { setF({ email: r.cred[0], password: r.cred[1] }); setErr(''); }}><Wand2 size={12} style={{ verticalAlign: -1 }} /> fill</button></p>
      </>)}
    </div></div></div>);
}

export function Register() {
  const { user, register } = useAuth(); const nav = useNavigate();
  const [f, setF] = useState({ name: '', email: '', phone: '', password: '' }); const [err, setErr] = useState(''); const [busy, setBusy] = useState(false);
  if (user) return <Navigate to={dashboardPath(user.role)} replace />;
  const set = (k) => (e) => setF({ ...f, [k]: e.target.value });
  const submit = async (e) => {
    e.preventDefault(); setErr('');
    if (!f.name.trim()) return setErr('Name is required');
    if (!/^\S+@\S+\.\S+$/.test(f.email)) return setErr('Enter a valid email');
    if (f.phone && !/^[6-9]\d{9}$/.test(f.phone)) return setErr('Enter a valid 10-digit mobile number');
    if (f.password.length < 6) return setErr('Password must be at least 6 characters');
    setBusy(true);
    try { const u = await register(f); nav(dashboardPath(u.role), { replace: true }); }
    catch (x) { setErr(errMsg(x)); } finally { setBusy(false); }
  };
  return (<div className="container"><div className="auth-split">
    <div className="side-art art-patient"><UserRound size={44} /><h2>Patient Registration</h2><p style={{ margin: 0, opacity: .9 }}>One account for all your SS Hospitals visits.</p><ul className="ul-check" style={{ color: '#fff' }}>{ROLES.patient.pts.map((p) => <li key={p}>{p}</li>)}</ul></div>
    <div className="form"><h2 style={{ margin: 0 }}>Create your account</h2>
      <form onSubmit={submit}>
        <input placeholder="Full name" value={f.name} onChange={set('name')} /><input type="email" placeholder="Email" value={f.email} onChange={set('email')} />
        <input placeholder="Mobile number" value={f.phone} onChange={set('phone')} /><input type="password" placeholder="Password (min 6)" value={f.password} onChange={set('password')} />
        {err && <div className="error">{err}</div>}<button className="btn" disabled={busy}>{busy ? 'Creating…' : 'Create account'}</button>
      </form><p className="muted">Already registered? <Link to="/login/patient">Patient login</Link></p></div></div></div>);
}
