import { useState } from 'react';
import { Link, useParams } from 'react-router-dom';
import { Phone, Siren } from 'lucide-react';
import useFetch from '../hooks/useFetch';
import { Loader, ErrorBox, PageHead, Empty, Avatar } from '../components/UI';
import { specIcon } from '../components/icons';
import { SPEC_INFO } from '../data/content';

export function Specialities() {
  const { data, loading, error } = useFetch('/specialities'); const [q, setQ] = useState('');
  const list = (data || []).filter((s) => !q || (s.name + ' ' + (s.treatments || []).join(' ') + ' ' + (s.conditions || []).join(' ')).toLowerCase().includes(q.toLowerCase()));
  return (<><PageHead crumb="Specialities" title="Medical Specialities" sub="Expert care across 18 specialities — search by speciality, treatment or condition" /><section className="container section">
    <input style={{ width: '100%', marginBottom: 22 }} placeholder="Search e.g. cardiology, knee pain, diabetes…" value={q} onChange={(e) => setQ(e.target.value)} />
    {loading ? <Loader /> : <><ErrorBox msg={error} />{!list.length ? <Empty /> : <div className="grid wide">{list.map((s) => { const I = specIcon(s.slug); return <Link key={s._id} to={`/specialities/${s.slug}`} className="card spec-card"><span className="ico"><I size={24} /></span><h3 style={{ margin: '10px 0 4px' }}>{s.name}</h3><p className="muted" style={{ margin: '0 0 8px' }}>{s.intro?.slice(0, 100)}…</p><div className="chips">{(s.treatments || []).slice(0, 3).map((t) => <span className="chip" key={t}>{t}</span>)}</div></Link>; })}</div>}</>}
  </section></>);
}

export function SpecialityDetail() {
  const { slug } = useParams();
  const { data: s, loading, error } = useFetch(`/specialities/${slug}`);
  const { data: docs } = useFetch(s ? `/doctors?speciality=${s._id}` : null);
  const all = useFetch('/specialities');
  if (loading) return <Loader />;
  if (error || !s) return <div className="container center-msg"><ErrorBox msg={error || 'Speciality not found'} /></div>;
  const x = SPEC_INFO[s.slug] || {}; const I = specIcon(s.slug);
  const bookTo = `/book?department=${s.department?._id || ''}&speciality=${s._id}`;
  return (<>
    <PageHead crumb={<><Link to="/specialities">Specialities</Link> › {s.name}</>} title={s.name} sub={s.intro} />
    <section className="container section"><div className="two-col">
      <div style={{ display: 'grid', gap: 18 }}>
        <div className="card pad"><div style={{ display: 'flex', gap: 14, alignItems: 'center' }}><span className="ico"><I size={26} /></span><div><h2 style={{ margin: 0 }}>About our {s.name} department</h2></div></div>
          <p style={{ lineHeight: 1.75 }}>{s.intro} Our specialists work as a team with nurses, technicians, dietitians and physiotherapists so you receive complete care — from diagnosis to recovery.</p></div>
        {s.conditions?.length > 0 && <div className="card pad"><h3>Conditions we treat</h3><div className="chips">{s.conditions.map((c) => <span className="chip" key={c}>{c}</span>)}</div></div>}
        {x.symptoms && <div className="card pad"><h3>Symptoms that need attention</h3><ul className="ul-check ul-warn">{x.symptoms.map((t) => <li key={t}>{t}</li>)}</ul>{x.see && <div className="callout">{x.see}</div>}</div>}
        <div className="grid wide">
          <div className="card pad"><h3>Treatments & procedures</h3><ul className="ul-check">{s.treatments.map((t) => <li key={t}>{t}</li>)}</ul></div>
          {x.diagnostics && <div className="card pad"><h3>Diagnostic tests</h3><ul className="ul-check">{x.diagnostics.map((t) => <li key={t}>{t}</li>)}</ul></div>}
          <div className="card pad"><h3>Facilities</h3><ul className="ul-check">{s.facilities.map((t) => <li key={t}>{t}</li>)}</ul></div>
        </div>
        {x.faqs && <div><h3>Frequently asked questions</h3><div className="accordion">{x.faqs.map(([q, a]) => <details key={q}><summary>{q}</summary><p className="muted">{a}</p></details>)}</div></div>}
        <div><h2>Our {s.name} doctors</h2>
          {!docs?.length ? <Empty text="No doctors listed yet." /> : <div className="grid wide">{docs.map((d) => <div key={d._id} className="card pad dcard"><div className="row"><Avatar name={d.name} /><div><h3>{d.name}</h3><span className="muted">{d.qualification}</span></div></div>
            <span className="muted">{d.designation}</span><div className="meta-line"><span>{d.experience} yrs experience</span><span>{d.branch?.city}</span><span className="fee">₹{d.fee}</span></div>
            <div className="actions"><Link className="btn btn-sm btn-outline" to={`/doctors/${d._id}`}>View Profile</Link><Link className="btn btn-sm" to={`/book?doctor=${d._id}`}>Book Appointment</Link></div></div>)}</div>}</div>
      </div>
      <aside className="sticky" style={{ display: 'grid', gap: 14 }}>
        <div className="card pad"><h3>Book an appointment</h3><p className="muted">Send a request; once the doctor accepts you get a token and estimated time.</p><Link className="btn" style={{ width: '100%', textAlign: 'center' }} to={bookTo}>Book in {s.name}</Link></div>
        <div className="card pad" style={{ background: '#fef3f2', borderColor: '#fecdca' }}><h3 style={{ color: '#b42318' }}><Siren size={16} style={{ verticalAlign: -2 }} /> Emergency</h3><p>24x7 emergency care.</p><a className="btn btn-danger" href="tel:108"><Phone size={14} style={{ verticalAlign: -2 }} /> Call 108</a></div>
        <div className="card pad"><h3>Other specialities</h3><div className="chips">{(all.data || []).filter((o) => o._id !== s._id).slice(0, 10).map((o) => <Link className="chip" key={o._id} to={`/specialities/${o.slug}`}>{o.name}</Link>)}</div></div>
      </aside>
    </div></section></>);
}
