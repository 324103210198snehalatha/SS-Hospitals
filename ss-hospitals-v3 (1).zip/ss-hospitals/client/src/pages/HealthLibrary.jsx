import { useMemo, useState } from 'react';
import { Link, useParams, useSearchParams } from 'react-router-dom';
import { PageHead, Empty, Tabs } from '../components/UI';
import { ARTICLES, DIETS, GROWTH, PREGNANCY, VACCINES, RANGES } from '../data/health';
import { DISEASES } from '../data/content';

const Sec = ({ s }) => { const [h, b] = s; return <><h2>{h}</h2>{Array.isArray(b) ? <ul className="ul-check">{b.map((i) => <li key={i}>{i}</li>)}</ul> : <p>{b}</p>}</>; };

function Bmi() {
  const [h, setH] = useState(''); const [w, setW] = useState('');
  const bmi = h > 0 && w > 0 ? w / ((h / 100) ** 2) : null;
  const cat = bmi == null ? '' : bmi < 18.5 ? 'Underweight' : bmi < 23 ? 'Healthy range' : bmi < 25 ? 'Overweight (Asian cut-off)' : 'Obese range (Asian cut-off)';
  const pos = bmi == null ? 0 : Math.min(98, Math.max(2, ((bmi - 14) / (36 - 14)) * 100));
  return (<div className="card pad"><h3>BMI calculator</h3><div className="two"><input type="number" placeholder="Height (cm)" value={h} onChange={(e) => setH(e.target.value)} /><input type="number" placeholder="Weight (kg)" value={w} onChange={(e) => setW(e.target.value)} /></div>
    {bmi != null && <><div className="bmi-bar"><i style={{ left: `${pos}%` }} /></div><b style={{ fontSize: 22 }}>{bmi.toFixed(1)}</b> <span className="tag">{cat}</span></>}
    <p className="muted" style={{ fontSize: 13 }}>BMI is a screening tool. It does not measure body fat or muscle. Discuss results with your doctor.</p></div>);
}
function DueDate() {
  const [d, setD] = useState('');
  const edd = d ? new Date(new Date(d + 'T00:00:00').getTime() + 280 * 86400000) : null;
  const wk = d ? Math.floor((Date.now() - new Date(d + 'T00:00:00').getTime()) / 86400000 / 7) : null;
  return (<div className="card pad"><h3>Pregnancy due-date calculator</h3><label className="l">First day of last menstrual period<input type="date" value={d} onChange={(e) => setD(e.target.value)} /></label>
    {edd && <p><b>Estimated due date:</b> {edd.toLocaleDateString('en-IN', { day: 'numeric', month: 'long', year: 'numeric' })}{wk >= 0 && wk <= 42 && <><br /><b>Current week:</b> about {wk}</>}</p>}
    <p className="muted" style={{ fontSize: 13 }}>Estimate based on a 28-day cycle (LMP + 280 days). Your scan dating is more accurate.</p></div>);
}
function Water() {
  const [w, setW] = useState('');
  return (<div className="card pad"><h3>Daily water guide</h3><input type="number" placeholder="Weight (kg)" value={w} onChange={(e) => setW(e.target.value)} />{w > 0 && <p><b>About {(w * 0.033).toFixed(1)} litres</b> a day (more in hot weather or with exercise).</p>}<p className="muted" style={{ fontSize: 13 }}>People with kidney, heart or liver conditions should follow their doctor’s fluid advice.</p></div>);
}

export function HealthLibrary() {
  const [sp, setSp] = useSearchParams(); const tab = sp.get('tab') || 'articles'; const [q, setQ] = useState(sp.get('q') || ''); const [diet, setDiet] = useState('diabetes'); const [sex, setSex] = useState('boys');
  const go = (t) => { const n = new URLSearchParams(); if (t !== 'articles') n.set('tab', t); setSp(n); };
  const t = q.toLowerCase();
  const arts = ARTICLES.filter((a) => !t || (a.title + a.tag + a.summary).toLowerCase().includes(t));
  const dis = DISEASES.filter((d) => !t || d.toLowerCase().includes(t));
  const dd = DIETS[diet]; const tr = useMemo(() => GROWTH.rows, []);
  return (<><PageHead crumb="Health Library" title="Health Library" sub="Trusted, easy-to-read guides, diet plans, growth charts and health tools" /><section className="container section">
    <Tabs value={tab} onChange={go} items={[['articles', 'Articles'], ['diet', 'Diet plans'], ['child', 'Child growth & vaccines'], ['pregnancy', 'Pregnancy care'], ['tools', 'Tools & normal ranges'], ['conditions', 'Conditions A–Z']]} />
    {(tab === 'articles' || tab === 'conditions') && <input style={{ width: '100%', marginBottom: 20 }} placeholder="Search articles and conditions" value={q} onChange={(e) => setQ(e.target.value)} />}

    {tab === 'articles' && (!arts.length ? <Empty /> : <div className="grid wide">{arts.map((a) => <Link key={a.slug} to={`/health-library/${a.slug}`} className="card spec-card"><span className="tag">{a.tag}</span><h3 style={{ margin: '10px 0 6px' }}>{a.title}</h3><p className="muted">{a.summary}</p><span className="read">{a.read} min read →</span></Link>)}</div>)}

    {tab === 'diet' && <><Tabs value={diet} onChange={setDiet} items={Object.entries(DIETS).map(([k, v]) => [k, v.title.split(' — ')[0].replace(' diet guide', '').replace(' diet', '')])} />
      <div className="card pad"><h2 style={{ marginTop: 0 }}>{dd.title}</h2><p className="note">{dd.note}</p>
        <div className="scroll"><table className="zebra"><thead><tr><th style={{ width: 160 }}>Meal</th><th>Sample menu</th></tr></thead><tbody>{dd.plan.map(([m, f]) => <tr key={m}><td><b>{m}</b></td><td>{f}</td></tr>)}</tbody></table></div>
        <div className="grid wide" style={{ marginTop: 18 }}><div><h3>✅ Prefer</h3><ul className="ul-check">{dd.eat.map((i) => <li key={i}>{i}</li>)}</ul></div><div><h3>⛔ Limit / avoid</h3><ul className="ul-check ul-x">{dd.limit.map((i) => <li key={i}>{i}</li>)}</ul></div></div></div></>}

    {tab === 'child' && <><div className="card pad"><div className="toolbar"><h2 style={{ margin: 0 }}>Child growth chart (0–10 years)</h2><div className="switch" style={{ minWidth: 180 }}><a href="#b" className={sex === 'boys' ? 'on' : ''} onClick={(e) => { e.preventDefault(); setSex('boys'); }}>Boys</a><a href="#g" className={sex === 'girls' ? 'on' : ''} onClick={(e) => { e.preventDefault(); setSex('girls'); }}>Girls</a></div></div>
      <p className="note">{GROWTH.note}</p><div className="scroll"><table className="zebra"><thead><tr><th>Age</th><th>Weight (kg)</th><th>Height (cm)</th></tr></thead><tbody>{tr.map((r) => <tr key={r[0]}><td><b>{r[0]}</b></td><td>{sex === 'boys' ? r[1] : r[3]}</td><td>{sex === 'boys' ? r[2] : r[4]}</td></tr>)}</tbody></table></div></div>
      <div className="grid wide" style={{ marginTop: 18 }}>
        <div className="card pad"><h3>Developmental milestones</h3><table className="zebra"><tbody>{GROWTH.milestones.map(([a, m]) => <tr key={a}><td><b>{a}</b></td><td>{m}</td></tr>)}</tbody></table></div>
        <div className="card pad"><h3>Vaccination schedule</h3><p className="note">{VACCINES.note}</p><table className="zebra"><tbody>{VACCINES.rows.map(([a, v]) => <tr key={a}><td><b>{a}</b></td><td>{v}</td></tr>)}</tbody></table></div></div></>}

    {tab === 'pregnancy' && <><div className="grid wide">{PREGNANCY.trimesters.map((tm) => <div className="card pad" key={tm.name}><span className="tag">{tm.weeks}</span><h3 style={{ margin: '8px 0' }}>{tm.name}</h3><p className="muted">{tm.body}</p><h4>Care tips</h4><ul className="ul-check">{tm.tips.map((i) => <li key={i}>{i}</li>)}</ul><h4>Usual tests</h4><div className="chips">{tm.tests.map((i) => <span className="chip" key={i}>{i}</span>)}</div></div>)}</div>
      <div className="callout"><b>Call your doctor or come to emergency if you notice:</b><ul>{PREGNANCY.warning.map((i) => <li key={i}>{i}</li>)}</ul></div><DueDate /></>}

    {tab === 'tools' && <><div className="grid wide"><Bmi /><Water /><DueDate /></div>
      <div className="card pad" style={{ marginTop: 18 }}><h2 style={{ marginTop: 0 }}>Normal ranges at a glance</h2><div className="scroll"><table className="zebra"><thead><tr><th>Test</th><th>Usual healthy range</th><th>Notes</th></tr></thead><tbody>{RANGES.map(([a, b, c]) => <tr key={a}><td><b>{a}</b></td><td>{b}</td><td className="muted">{c}</td></tr>)}</tbody></table></div><p className="muted" style={{ fontSize: 13 }}>Reference ranges vary by laboratory, age and health condition. Always interpret results with your doctor.</p></div></>}

    {tab === 'conditions' && <><h2>Diseases & conditions</h2><div className="chips">{dis.map((d) => <Link key={d} className="chip" to={`/doctors`}>{d}</Link>)}{!dis.length && <Empty />}</div><p className="muted" style={{ marginTop: 14 }}>Select a condition to find the right doctor.</p></>}
    <p className="note" style={{ marginTop: 26 }}>General health information for education only — not a substitute for professional medical advice, diagnosis or treatment. Content is sample material for demonstration; have your doctors review it before publishing.</p>
  </section></>);
}

export function Article() {
  const { slug } = useParams(); const a = ARTICLES.find((x) => x.slug === slug);
  if (!a) return <div className="container center-msg"><h2>Article not found</h2><Link to="/health-library">Back to library</Link></div>;
  const more = ARTICLES.filter((x) => x.slug !== a.slug).slice(0, 4);
  return <><PageHead crumb={<><Link to="/health-library">Health Library</Link> › {a.tag}</>} title={a.title} sub={`${a.tag} • ${a.read} min read`} /><section className="container section"><div className="two-col">
    <article className="article card pad"><p style={{ fontSize: 18 }}><b>{a.summary}</b></p>{a.sections.map((s) => <Sec key={s[0]} s={s} />)}<div className="callout"><b>When to seek medical help:</b> {a.when}</div><p className="muted">General information only; consult a doctor for advice.</p><Link to="/health-library">← Back to library</Link></article>
    <aside className="sticky" style={{ display: 'grid', gap: 14 }}><div className="card pad"><h3>Talk to a specialist</h3><p className="muted">Have questions about {a.tag.toLowerCase()}?</p><Link className="btn" to="/doctors">Find a doctor</Link></div><div className="card pad"><h3>More to read</h3>{more.map((m) => <p key={m.slug} style={{ margin: '8px 0' }}><Link to={`/health-library/${m.slug}`}>{m.title}</Link></p>)}</div></aside>
  </div></section></>;
}
