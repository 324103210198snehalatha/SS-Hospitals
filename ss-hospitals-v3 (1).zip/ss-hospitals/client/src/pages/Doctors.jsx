import { Link, useParams, useSearchParams } from 'react-router-dom';
import { Languages, GraduationCap, MapPin, Clock } from 'lucide-react';
import useFetch from '../hooks/useFetch';
import { Loader, ErrorBox, PageHead, Empty, Avatar, WeekStrip } from '../components/UI';

export function Doctors() {
  const [sp, setSp] = useSearchParams();
  const f = { q: sp.get('q') || '', speciality: sp.get('speciality') || '', department: sp.get('department') || '', branch: sp.get('branch') || '', gender: sp.get('gender') || '' };
  const set = (k) => (e) => { const n = new URLSearchParams(sp); e.target.value ? n.set(k, e.target.value) : n.delete(k); setSp(n); };
  const qs = new URLSearchParams(Object.entries(f).filter(([k, v]) => v && k !== 'gender')).toString();
  const { data, loading, error } = useFetch(`/doctors?${qs}`);
  const specs = useFetch('/specialities'); const br = useFetch('/branches');
  const list = (data || []).filter((d) => !f.gender || d.gender === f.gender);
  return (<><PageHead crumb="Find a Doctor" title="Find a Doctor" sub="Search by name, speciality, hospital location or gender" /><section className="container section">
    <div className="filters">
      <input placeholder="Doctor name" value={f.q} onChange={set('q')} />
      <select value={f.speciality} onChange={set('speciality')}><option value="">All specialities</option>{(specs.data || []).map((s) => <option key={s._id} value={s._id}>{s.name}</option>)}</select>
      <select value={f.branch} onChange={set('branch')}><option value="">All locations</option>{(br.data || []).map((s) => <option key={s._id} value={s._id}>{s.city}</option>)}</select>
      <select value={f.gender} onChange={set('gender')}><option value="">Any gender</option><option value="F">Female doctor</option><option value="M">Male doctor</option></select>
    </div>
    {loading ? <Loader /> : <><ErrorBox msg={error} /><p className="muted">{list.length} doctor{list.length === 1 ? '' : 's'} found</p>{!list.length ? <Empty text="No doctors match your search." /> :
      <div className="grid wide">{list.map((d) => <div key={d._id} className="card pad dcard">
        <div className="row"><Avatar name={d.name} /><div><h3>{d.name}</h3><span className="muted" style={{ fontSize: 13 }}>{d.qualification}</span></div></div>
        <div><span className="tag">{d.speciality?.name}</span> <span className="muted" style={{ fontSize: 13 }}>{d.designation?.split(',')[0]}</span></div>
        <div className="meta-line"><span><Clock size={13} style={{ verticalAlign: -2 }} /> {d.experience} yrs</span><span><MapPin size={13} style={{ verticalAlign: -2 }} /> {d.branch?.city}</span><span className="fee">₹{d.fee}</span></div>
        {d.languages?.length > 0 && <div className="meta-line"><span><Languages size={13} style={{ verticalAlign: -2 }} /> {d.languages.join(', ')}</span></div>}
        <WeekStrip doctor={d} />
        <div className="actions"><Link className="btn btn-sm btn-outline" to={`/doctors/${d._id}`}>View Profile</Link><Link className="btn btn-sm" to={`/book?doctor=${d._id}`}>Book Appointment</Link></div></div>)}</div>}</>}
  </section></>);
}

export function DoctorProfile() {
  const { id } = useParams(); const { data: d, loading, error } = useFetch(`/doctors/${id}`);
  const rel = useFetch(d ? `/doctors?speciality=${d.speciality?._id}` : null);
  if (loading) return <Loader />;
  if (error || !d) return <div className="container center-msg"><ErrorBox msg={error || 'Doctor not found'} /></div>;
  const others = (rel.data || []).filter((x) => x._id !== d._id);
  return (<>
    <section className="pagehead2"><div className="container" style={{ display: 'flex', gap: 22, alignItems: 'center', flexWrap: 'wrap' }}>
      <Avatar name={d.name} size="lg" /><div><div className="crumbs"><Link to="/doctors">Find a Doctor</Link> › {d.name}</div><h1 style={{ margin: '0 0 4px' }}>{d.name}</h1><p>{d.qualification} • {d.designation}</p></div></div></section>
    <section className="container section"><div className="two-col">
      <div style={{ display: 'grid', gap: 18 }}>
        <div className="card pad"><h3>About</h3><p style={{ lineHeight: 1.75 }}>{d.bio}</p></div>
        <div className="grid wide">
          <div className="card pad"><h3><GraduationCap size={18} style={{ verticalAlign: -3 }} /> Education</h3><ul className="ul-check">{(d.education || []).map((e) => <li key={e}>{e}</li>)}</ul></div>
          <div className="card pad"><h3>Areas of expertise</h3><div className="chips">{(d.expertise || []).map((e) => <span className="chip" key={e}>{e}</span>)}</div><h3 style={{ marginTop: 18 }}><Languages size={18} style={{ verticalAlign: -3 }} /> Languages</h3><div className="chips">{(d.languages || []).map((e) => <span className="chip" key={e}>{e}</span>)}</div></div>
        </div>
        <div className="card pad"><h3>Weekly availability</h3><WeekStrip doctor={d} /><p className="muted">Morning 9:00–12:00 and evening 4:00–6:00 sessions on available days. Book to see exact slots.</p></div>
        {others.length > 0 && <div><h3>Other {d.speciality?.name} doctors</h3><div className="grid wide">{others.slice(0, 3).map((o) => <Link key={o._id} to={`/doctors/${o._id}`} className="card pad" style={{ color: 'inherit', display: 'flex', gap: 12, alignItems: 'center' }}><Avatar name={o.name} /><div><b>{o.name}</b><div className="muted" style={{ fontSize: 13 }}>{o.qualification}</div></div></Link>)}</div></div>}
      </div>
      <aside className="card pad sticky" style={{ display: 'grid', gap: 10 }}>
        <h3 style={{ margin: 0 }}>Consultation</h3>
        <div className="fee" style={{ fontSize: 28 }}>₹{d.fee}</div>
        <div className="meta-line" style={{ display: 'grid' }}><span><b>Department:</b> {d.department?.name}</span><span><b>Experience:</b> {d.experience} years</span><span><MapPin size={13} style={{ verticalAlign: -2 }} /> {d.branch?.name}</span></div>
        <Link className="btn" style={{ textAlign: 'center' }} to={`/book?doctor=${d._id}`}>Book Appointment</Link>
        <p className="muted" style={{ margin: 0, fontSize: 13 }}>Doctor accepts your request → you get a token and estimated time.</p>
      </aside>
    </div></section></>);
}
