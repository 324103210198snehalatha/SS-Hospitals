import { Link, NavLink, useParams } from 'react-router-dom';
import { Phone } from 'lucide-react';
import { PageHead } from '../components/UI';
import { CARE_ICONS } from '../components/icons';
import useFetch from '../hooks/useFetch';
import { CARE } from '../data/content';

const keys = Object.keys(CARE);
export default function PatientCare() {
  const { section } = useParams(); const c = CARE[section]; const sv = useFetch('/services');
  if (section && !c) return <div className="container center-msg"><h2>Section not found</h2><Link to="/patient-care">Back to Patient Care</Link></div>;
  return (<>
    <PageHead crumb={c ? <>Patient Care › {c.title}</> : 'Patient Care'} title={c ? c.title : 'Patient Care'} sub={c ? c.intro : 'Everything you need to know before, during and after your visit to SS Hospitals'} />
    <section className="container section"><div className="two-col" style={{ gridTemplateColumns: '260px 1fr' }}>
      <aside className="card pad sticky" style={{ display: 'grid', gap: 4 }}>
        <NavLink to="/patient-care" end style={{ padding: '10px 12px', borderRadius: 10 }} className={({ isActive }) => isActive ? 'pill on' : ''}>Overview</NavLink>
        {keys.map((k) => <NavLink key={k} to={`/patient-care/${k}`} style={{ padding: '10px 12px', borderRadius: 10 }} className={({ isActive }) => isActive ? 'pill on' : ''}>{CARE[k].title}</NavLink>)}
        <div className="note" style={{ marginTop: 10 }}>Emergency? Call <b>108</b></div>
      </aside>
      <div>
        {!c ? <>
          <div className="grid wide">{keys.map((k) => { const I = CARE_ICONS[CARE[k].icon]; return <Link key={k} to={`/patient-care/${k}`} className="card spec-card"><span className="ico">{I && <I size={22} />}</span><h3 style={{ margin: '10px 0 4px' }}>{CARE[k].title}</h3><p className="muted">{CARE[k].intro}</p></Link>; })}</div>
          <h2 style={{ marginTop: 34 }}>Healthcare services</h2>
          <div className="grid wide">{(sv.data || []).map((s) => <Link key={s._id} to={`/services/${s.slug}`} className="card spec-card"><h3>{s.title}</h3><p className="muted">{s.summary}</p></Link>)}</div>
        </> : <>
          <div className="grid wide">{c.blocks.map(([t, items]) => <div className="card pad" key={t}><h3>{t}</h3><ul className={`ul-check ${section === 'emergency' && t === 'When to come' ? 'ul-warn' : ''}`}>{items.map((i) => <li key={i}>{i}</li>)}</ul></div>)}</div>
          {section === 'emergency' && <div className="emergency-strip" style={{ borderRadius: 16, marginTop: 20 }}><div className="container"><div><h3>Emergency helpline</h3><span>Open 24x7 at every branch</span></div><a className="btn" href="tel:108"><Phone size={15} style={{ verticalAlign: -2 }} /> Call 108</a></div></div>}
          <div className="actions" style={{ marginTop: 22 }}><Link className="btn" to="/book">Book an Appointment</Link><Link className="btn btn-outline" to="/hospitals">Find a hospital</Link><Link className="btn btn-outline" to="/contact">Contact us</Link></div>
        </>}
      </div>
    </div></section></>);
}
