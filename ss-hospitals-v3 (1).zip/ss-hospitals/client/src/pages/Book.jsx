import { useEffect, useState } from 'react';
import { Link, Navigate, useLocation, useSearchParams } from 'react-router-dom';
import useFetch from '../hooks/useFetch';
import api, { errMsg } from '../services/api';
import { useAuth } from '../context/AuthContext';
import { Loader, ErrorBox, PageHead, today, fmtDate, fmtTime } from '../components/UI';

export default function Book() {
  const { user, loading: authLoading } = useAuth(); const loc = useLocation(); const [sp] = useSearchParams();
  const depts = useFetch('/departments'); const specs = useFetch('/specialities'); const docs = useFetch('/doctors');
  const [s, setS] = useState({ department: sp.get('department') || '', speciality: sp.get('speciality') || '', doctor: sp.get('doctor') || '', date: '', slot: '' });
  const [slots, setSlots] = useState([]); const [slotMsg, setSlotMsg] = useState('');
  const [p, setP] = useState({ patientName: '', patientAge: '', patientPhone: '', reason: '' });
  const [err, setErr] = useState(''); const [busy, setBusy] = useState(false); const [done, setDone] = useState(null);

  useEffect(() => { if (user) setP((x) => ({ ...x, patientName: x.patientName || user.name, patientPhone: x.patientPhone || user.phone || '' })); }, [user]);
  // When arriving with ?doctor=, derive department and speciality
  useEffect(() => {
    const d = docs.data?.find((x) => x._id === sp.get('doctor'));
    if (d) setS((x) => ({ ...x, department: d.department._id, speciality: d.speciality._id }));
  }, [docs.data]); // eslint-disable-line
  useEffect(() => {
    setSlots([]); setSlotMsg('');
    if (!s.doctor || !s.date) return;
    api.get(`/doctors/${s.doctor}/slots`, { params: { date: s.date } }).then((r) => { setSlots(r.data.slots); if (!r.data.slots.length) setSlotMsg('No slots available on this date. Try another date.'); }).catch((e) => setSlotMsg(errMsg(e)));
  }, [s.doctor, s.date]);

  if (authLoading || depts.loading || specs.loading || docs.loading) return <Loader />;
  if (!user) return <Navigate to="/login/patient" state={{ from: loc.pathname + loc.search }} replace />;
  if (user.role !== 'patient') return <div className="container center-msg"><h2>Only patients can book appointments</h2><p>Log in with a patient account.</p></div>;

  const specList = (specs.data || []).filter((x) => !s.department || x.department?._id === s.department);
  const docList = (docs.data || []).filter((d) => (!s.department || d.department._id === s.department) && (!s.speciality || d.speciality._id === s.speciality));
  const chosen = docs.data?.find((d) => d._id === s.doctor);

  const submit = async (e) => {
    e.preventDefault(); setErr('');
    if (!s.doctor) return setErr('Select a doctor'); if (!s.date) return setErr('Select a date'); if (!s.slot) return setErr('Select a time slot');
    if (!p.patientName.trim()) return setErr('Enter patient name');
    if (!(p.patientAge >= 0 && p.patientAge <= 120 && p.patientAge !== '')) return setErr('Enter a valid age');
    if (!/^[6-9]\d{9}$/.test(p.patientPhone)) return setErr('Enter a valid 10-digit mobile number');
    setBusy(true);
    try { setDone((await api.post('/appointments', { ...s, ...p })).data); } catch (x) { setErr(errMsg(x)); setS({ ...s, slot: '' }); } finally { setBusy(false); }
  };
  if (done) return (<section className="container section" style={{ maxWidth: 560 }}><div className="card pad"><h2>Request sent ✅</h2>
    <p><b>{done.doctor?.name}</b><br />{fmtDate(done.date)} • requested time {fmtTime(done.slot)}</p>
    <div className="ticket pend"><div className="no"><small>TOKEN</small><b>—</b></div><div><b>Waiting for the doctor to accept</b><div className="muted">Your token number and estimated time will appear in <Link to="/patient">My Appointments</Link> as soon as the doctor accepts.</div></div></div>
    <div className="actions"><Link className="btn" to="/patient">My Appointments</Link><Link className="btn btn-outline" to="/">Home</Link></div></div></section>);

  return (<><PageHead title="Book an Appointment" sub="Send a request — the doctor accepts it and you get a token and estimated time" /><section className="container section" style={{ maxWidth: 760 }}>
    <form className="stack" onSubmit={submit}>
      <div className="two">
        <label className="l">Department<select value={s.department} onChange={(e) => setS({ ...s, department: e.target.value, speciality: '', doctor: '', slot: '' })}><option value="">Select department</option>{depts.data.map((d) => <option key={d._id} value={d._id}>{d.name}</option>)}</select></label>
        <label className="l">Speciality<select value={s.speciality} onChange={(e) => setS({ ...s, speciality: e.target.value, doctor: '', slot: '' })}><option value="">Select speciality</option>{specList.map((d) => <option key={d._id} value={d._id}>{d.name}</option>)}</select></label>
      </div>
      <label className="l">Doctor<select value={s.doctor} onChange={(e) => setS({ ...s, doctor: e.target.value, slot: '' })}><option value="">Select doctor</option>{docList.map((d) => <option key={d._id} value={d._id}>{d.name} — {d.speciality?.name} ({d.branch?.city})</option>)}</select></label>
      {chosen && <p className="muted">Consultation fee: ₹{chosen.fee}</p>}
      <label className="l">Date<input type="date" min={today()} value={s.date} onChange={(e) => setS({ ...s, date: e.target.value, slot: '' })} /></label>
      {s.doctor && s.date && <div><div className="l">Available time slots</div>{slotMsg && <p className="muted">{slotMsg}</p>}<div className="slots">{slots.map((t) => <button type="button" key={t} className={`slot ${s.slot === t ? 'on' : ''}`} onClick={() => setS({ ...s, slot: t })}>{fmtTime(t)}</button>)}</div></div>}
      <h3>Patient details</h3>
      <div className="two"><input placeholder="Patient name" value={p.patientName} onChange={(e) => setP({ ...p, patientName: e.target.value })} /><input type="number" placeholder="Age" value={p.patientAge} onChange={(e) => setP({ ...p, patientAge: e.target.value })} /></div>
      <input placeholder="Mobile number (10 digits)" value={p.patientPhone} onChange={(e) => setP({ ...p, patientPhone: e.target.value })} />
      <textarea rows="3" placeholder="Reason for visit (optional)" value={p.reason} onChange={(e) => setP({ ...p, reason: e.target.value })} />
      <ErrorBox msg={err} /><button className="btn" disabled={busy}>{busy ? 'Sending…' : 'Send appointment request'}</button>
    </form></section></>);
}
