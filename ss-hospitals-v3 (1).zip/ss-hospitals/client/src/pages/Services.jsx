import { Link, useParams } from 'react-router-dom';
import useFetch from '../hooks/useFetch';
import { Loader, ErrorBox, PageHead } from '../components/UI';

export function Services() {
  const { data, loading, error } = useFetch('/services');
  return (<><PageHead crumb="Services" title="Healthcare Services" sub="Everything you need, under one roof" /><section className="container section">
    {loading ? <Loader /> : <><ErrorBox msg={error} /><div className="grid wide">{(data || []).map((s) => <Link key={s._id} to={`/services/${s.slug}`} className="card spec-card"><div className="dot">{s.title[0]}</div><h3>{s.title}</h3><p className="muted">{s.summary}</p></Link>)}</div></>}
  </section></>);
}
export function ServiceDetail() {
  const { slug } = useParams();
  const { data: s, loading, error } = useFetch(`/services/${slug}`);
  if (loading) return <Loader />;
  if (error || !s) return <div className="container center-msg"><ErrorBox msg={error || 'Service not found'} /></div>;
  const points = (s.details || '').split('\n').filter(Boolean);
  return (<><PageHead crumb={<><Link to="/services">Services</Link> › {s.title}</>} title={s.title} sub={s.summary} /><section className="container section"><div className="two-col">
    <div className="card pad"><h3>What this service includes</h3><ul className="ul-check">{points.map((p) => <li key={p}>{p}</li>)}</ul></div>
    <div className="card pad"><h3>Need this service?</h3><p className="muted">Book a consultation or talk to our team.</p><div className="actions"><Link className="btn" to="/book">Book Appointment</Link><Link className="btn btn-outline" to="/contact">Contact Us</Link></div></div>
  </div></section></>);
}
