import { useState } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { CalendarCheck, Stethoscope, Siren, ClipboardList, Search, ShieldCheck, Clock, Award, ArrowRight, MapPin, Phone, LogIn, BookOpen } from 'lucide-react';
import useFetch from '../hooks/useFetch';
import api, { errMsg } from '../services/api';
import { Loader, Avatar } from '../components/UI';
import { specIcon } from '../components/icons';
import { ARTICLES } from '../data/health';
import { DISEASES, NEWS, TESTIMONIALS, FAQS, STATS, WHY_US, ABOUT } from '../data/content';

const QUICK = [[CalendarCheck, 'Book Appointment', 'Get a token & estimated time', '/book', ''], [Stethoscope, 'Find a Doctor', '36+ specialists', '/doctors', 't'], [ClipboardList, 'Health Check-ups', 'Packages from ₹1,299', '/health-checkup', 'o'], [LogIn, 'Patient Portal', 'Appointments & records', '/login/patient', '']];
const STEPS = [['1', 'Request', 'Choose your doctor, date and time and send a request.'], ['2', 'Doctor accepts', 'The doctor reviews and accepts your request.'], ['3', 'Token & time', 'You get a token number and an estimated consultation time.'], ['4', 'Visit', 'Arrive a little early, watch your queue status, and consult.']];

function Newsletter() {
  const [email, setEmail] = useState(''); const [msg, setMsg] = useState(''); const [err, setErr] = useState('');
  const submit = async (e) => {
    e.preventDefault(); setErr(''); setMsg('');
    if (!/^\S+@\S+\.\S+$/.test(email)) return setErr('Enter a valid email');
    try { await api.post('/inquiries', { type: 'newsletter', email }); setMsg('Subscribed. Thank you!'); setEmail(''); } catch (x) { setErr(errMsg(x)); }
  };
  return (
    <section className="section newsletter"><div className="container">
      <h2>Stay healthy with our newsletter</h2><p className="sub">Health tips and hospital updates in your inbox.</p>
      <form onSubmit={submit}><input type="email" placeholder="Your email" value={email} onChange={(e) => setEmail(e.target.value)} /><button className="btn">Subscribe</button></form>
      {msg && <p className="ok" style={{ display: 'inline-block', marginTop: 12 }}>{msg}</p>}{err && <p className="error" style={{ display: 'inline-block', marginTop: 12 }}>{err}</p>}
    </div></section>
  );
}

export default function Home() {
  const [f, setF] = useState({ q: '', speciality: '', branch: '' }); const [letter, setLetter] = useState('A'); const nav = useNavigate();
  const specs = useFetch('/specialities'); const pk = useFetch('/packages'); const br = useFetch('/branches'); const sv = useFetch('/services'); const docs = useFetch('/doctors');
  const letters = [...new Set(DISEASES.map((d) => d[0]))].sort();
  const go = (e) => { e.preventDefault(); const p = new URLSearchParams(Object.entries(f).filter(([, v]) => v)); nav(`/doctors?${p}`); };
  const popular = (pk.data || []).filter((p) => p.popular).concat((pk.data || []).filter((p) => !p.popular)).slice(0, 4);
  return (
    <>
      <section className="hero2"><div className="container in">
        <div>
          <span className="eyebrow" style={{ color: '#e6c37a' }}>Smart Multispeciality Hospital • Since 2007</span>
          <h1>Caring for you, <em>every step</em> of the way.</h1>
          <p className="lead">Expert doctors across 18 specialities, advanced diagnostics and a smart token system — so you spend less time waiting and more time healing.</p>
          <div style={{ display: 'flex', gap: 12, flexWrap: 'wrap' }}><Link to="/book" className="btn btn-light btn-lg">Book an Appointment</Link><Link to="/doctors" className="btn btn-ghost btn-lg">Find a Doctor</Link></div>
          <div className="hero-badges"><span><ShieldCheck size={18} /> Trusted by thousands of families</span><span><Clock size={18} /> 24x7 Emergency</span><span><Award size={18} /> 18 Specialities</span></div>
        </div>
        <div className="hero-art"><div className="hero-card">
          <h4>How your visit works</h4>
          {STEPS.map(([n, t, d]) => <div className="hero-row" key={n}><span><b>{n}. {t}</b></span><span style={{ opacity: .8, textAlign: 'right', maxWidth: 190 }}>{d.split('.')[0]}</span></div>)}
          <div className="token-pill"><b>#07</b><div><b style={{ fontSize: 15 }}>Your token</b><div style={{ fontSize: 13, color: '#667085' }}>Estimated time 10:30 AM</div></div></div>
        </div></div>
      </div></section>

      <section className="container search-card"><form className="box" onSubmit={go}>
        <input value={f.q} onChange={(e) => setF({ ...f, q: e.target.value })} placeholder="Doctor name…" />
        <select value={f.speciality} onChange={(e) => setF({ ...f, speciality: e.target.value })}><option value="">Any speciality</option>{(specs.data || []).map((s) => <option key={s._id} value={s._id}>{s.name}</option>)}</select>
        <select value={f.branch} onChange={(e) => setF({ ...f, branch: e.target.value })}><option value="">Any location</option>{(br.data || []).map((b) => <option key={b._id} value={b._id}>{b.city}</option>)}</select>
        <button className="btn"><Search size={16} style={{ verticalAlign: -3 }} /> Search</button>
      </form>
        <div className="qgrid">{QUICK.map(([I, l, s, to, c]) => <Link key={l} to={to} className="card qcard"><span className={`ico ${c}`}><I size={24} /></span><span><b>{l}</b><br /><span className="muted">{s}</span></span></Link>)}</div>
      </section>

      <section className="container section"><div className="emergency-strip" style={{ borderRadius: 18, overflow: 'hidden' }}><div className="container">
        <div style={{ display: 'flex', gap: 14, alignItems: 'center' }}><Siren size={36} /><div><h3>Medical emergency? We’re open 24x7.</h3><span style={{ opacity: .9 }}>Ambulance, trauma, cardiac and stroke care at every branch.</span></div></div>
        <div style={{ display: 'flex', gap: 10, flexWrap: 'wrap' }}><a className="btn" href="tel:108"><Phone size={15} style={{ verticalAlign: -2 }} /> Call 108</a><Link className="btn btn-ghost" to="/patient-care/emergency">Emergency info</Link></div>
      </div></div></section>

      <section className="container section"><div className="section-head"><div><span className="eyebrow">Why SS Hospitals</span><h2>Healthcare built around you</h2></div></div>
        <div className="grid wide">{WHY_US.map(([t, d]) => <div className="card feature" key={t}><span className="ico t"><ShieldCheck size={22} /></span><div><h4>{t}</h4><p>{d}</p></div></div>)}</div>
      </section>

      <section className="band"><div className="container section">
        <div className="section-head"><div><span className="eyebrow">Centres of Excellence</span><h2>Medical Specialities</h2><p>Care across every major speciality</p></div><Link to="/specialities" className="btn btn-outline btn-sm">View all <ArrowRight size={14} style={{ verticalAlign: -2 }} /></Link></div>
        {specs.loading ? <Loader /> : <div className="grid">{(specs.data || []).map((s) => { const I = specIcon(s.slug); return <Link key={s._id} to={`/specialities/${s.slug}`} className="card spec-tile"><span className="ico"><I size={22} /></span><b>{s.name}</b><span className="muted">{s.treatments?.slice(0, 2).join(' • ')}</span></Link>; })}</div>}
      </div></section>

      <section className="container section"><div className="section-head"><div><span className="eyebrow">Our doctors</span><h2>Meet our specialists</h2><p>Experienced consultants, ready to help</p></div><Link to="/doctors" className="btn btn-outline btn-sm">All doctors <ArrowRight size={14} style={{ verticalAlign: -2 }} /></Link></div>
        {docs.loading ? <Loader /> : <div className="hscroll">{(docs.data || []).filter((_, i) => i % 3 === 0).slice(0, 10).map((d) => <Link key={d._id} to={`/doctors/${d._id}`} className="card pad dcard" style={{ color: 'inherit' }}>
          <div className="row"><Avatar name={d.name} /><div><h3 style={{ fontSize: 17 }}>{d.name}</h3><span className="tag">{d.speciality?.name}</span></div></div>
          <span className="muted">{d.designation}</span><span className="meta-line"><span>{d.experience} yrs</span><span>{d.branch?.city}</span></span></Link>)}</div>}
      </section>

      <section className="band"><div className="container section"><div className="section-head"><div><span className="eyebrow">Simple & smart</span><h2>How appointments work</h2></div></div>
        <div className="grid">{STEPS.map(([n, t, d]) => <div className="card pad" key={n}><div className="tk">{n}</div><h3 style={{ marginTop: 10 }}>{t}</h3><p className="muted">{d}</p></div>)}</div>
        <p style={{ marginTop: 18 }}><Link className="btn" to="/book">Book now</Link></p>
      </div></section>

      <section className="container section"><div className="section-head"><div><span className="eyebrow">Healthcare services</span><h2>Everything under one roof</h2></div><Link to="/services" className="btn btn-outline btn-sm">All services</Link></div>
        <div className="grid wide">{(sv.data || []).slice(0, 6).map((s) => <Link key={s._id} to={`/services/${s.slug}`} className="card spec-card"><h3>{s.title}</h3><p className="muted">{s.summary}</p></Link>)}</div>
      </section>

      <section className="band"><div className="container section"><div className="section-head"><div><span className="eyebrow">Preventive care</span><h2>Health check-up packages</h2><p>Sample packages and prices</p></div><Link to="/health-checkup" className="btn btn-outline btn-sm">All packages</Link></div>
        <div className="grid">{popular.map((p) => <div key={p._id} className="card pkg">{p.popular && <span className="ribbon">Popular</span>}<h3>{p.name}</h3><span className="muted">{p.suitableFor}</span><div><span className="price">₹{p.price}</span>{p.originalPrice && <s>₹{p.originalPrice}</s>}</div><span className="muted">{p.tests.length} tests • Report: {p.reportTime}</span><Link className="btn btn-sm" to={`/health-checkup?book=${p._id}`}>Book now</Link></div>)}</div>
      </div></section>

      <section className="container section"><div className="two-col" style={{ gridTemplateColumns: '1.2fr 1fr' }}>
        <div><span className="eyebrow">Our story</span><h2>From a 30-bed hospital to a family of eight</h2><p className="muted" style={{ fontSize: 16, lineHeight: 1.75 }}>{ABOUT.story[0]}</p><p className="muted" style={{ fontSize: 16, lineHeight: 1.75 }}>{ABOUT.story[1].slice(0, 190)}…</p><Link className="btn btn-outline" to="/about">Read our story</Link></div>
        <div className="card pad"><h3>Milestones</h3><div className="timeline">{ABOUT.timeline.slice(0, 5).map(([y, t]) => <div key={y}><b>{y}</b><div className="muted">{t}</div></div>)}</div></div>
      </div></section>

      <section className="stats2"><div className="container grid">{STATS.map(([n, l]) => <div key={l}><b>{n}</b><span>{l}</span></div>)}</div></section>

      <section className="container section"><div className="section-head"><div><span className="eyebrow">Find us</span><h2>Our locations</h2></div><Link to="/hospitals" className="btn btn-outline btn-sm">All hospitals</Link></div>
        <div className="grid">{(br.data || []).map((b) => <Link to={`/hospitals?city=${b.city}`} key={b._id} className="card pad" style={{ color: 'inherit' }}><h3 style={{ fontSize: 17 }}>{b.city}</h3><p className="muted" style={{ margin: '4px 0' }}>{b.state} • {b.beds} beds</p><span style={{ fontSize: 14 }}><MapPin size={13} style={{ verticalAlign: -2 }} /> {b.isMain ? 'Main hospital' : 'Branch'}</span></Link>)}</div>
      </section>

      <section className="band"><div className="container section"><div className="section-head"><div><span className="eyebrow">Health library</span><h2>Learn. Prevent. Live well.</h2></div><Link to="/health-library" className="btn btn-outline btn-sm"><BookOpen size={14} style={{ verticalAlign: -2 }} /> Open library</Link></div>
        <div className="grid wide">{ARTICLES.slice(0, 3).map((a) => <Link key={a.slug} to={`/health-library/${a.slug}`} className="card spec-card"><span className="tag">{a.tag}</span><h3 style={{ margin: '8px 0' }}>{a.title}</h3><p className="muted">{a.summary}</p><span className="read">{a.read} min read</span></Link>)}</div>
        <h3 style={{ marginTop: 28 }}>Diseases & Conditions A–Z</h3>
        <div className="az">{letters.map((l) => <button key={l} className={l === letter ? 'on' : ''} onClick={() => setLetter(l)}>{l}</button>)}</div>
        <div className="chips">{DISEASES.filter((d) => d[0] === letter).map((d) => <Link key={d} className="chip" to={`/health-library?tab=conditions&q=${d}`}>{d}</Link>)}</div>
      </div></section>

      <section className="container section"><div className="section-head"><div><span className="eyebrow">News</span><h2>Latest from SS Hospitals</h2></div></div>
        <div className="grid wide">{NEWS.map((n) => <div key={n.title} className="card pad"><span className="tag">{n.date}</span><h3 style={{ margin: '10px 0 6px' }}>{n.title}</h3><p className="muted">{n.text}</p></div>)}</div></section>
      <section className="band"><div className="container section"><div className="section-head"><div><span className="eyebrow">Patient stories</span><h2>What our patients say</h2><p>Sample testimonials</p></div></div>
        <div className="grid wide">{TESTIMONIALS.map((t) => <div key={t.name} className="card tcard"><p>{t.text}</p><b>{t.name}</b><div className="muted">{t.place}</div></div>)}</div></div></section>
      <section className="container section" style={{ maxWidth: 820 }}><h2>Frequently asked questions</h2><div className="accordion">{FAQS.map(([q1, a]) => <details key={q1}><summary>{q1}</summary><p className="muted">{a}</p></details>)}</div></section>
      <section className="container" style={{ marginBottom: 30 }}><div className="cta-band"><div><h2>Need a doctor today?</h2><span style={{ opacity: .92 }}>Request an appointment in under two minutes.</span></div><Link className="btn btn-light btn-lg" to="/book">Book an Appointment</Link></div></section>
      <Newsletter />
    </>
  );
}
