import { useEffect, useState } from 'react';
import useFetch from '../hooks/useFetch';
import api, { errMsg } from '../services/api';
import { useAuth } from '../context/AuthContext';
import { Loader, ErrorBox, Empty, Status, days, today, fmtDate, fmtTime } from '../components/UI';
import { BarStack, Donut, LineChart } from '../components/Charts';

const COLORS = { pending: '#f79009', accepted: '#14a39a', in_consultation: '#7a5af8', completed: '#12b76a', rejected: '#f04438', cancelled: '#98a2b3', no_show: '#667085' };
const NAMES = { pending: 'Pending', accepted: 'Accepted', in_consultation: 'In consultation', completed: 'Completed', rejected: 'Rejected', cancelled: 'Cancelled', no_show: 'No-show' };
const useAuto = (reload, ms = 20000) => useEffect(() => { const t = setInterval(reload, ms); return () => clearInterval(t); }, [reload, ms]);
const putStatus = (id, body) => api.put(`/appointments/${id}/status`, body);

// ---------- Overview: counts + charts ----------
export function DoctorHome() {
  const { user } = useAuth(); const { data: s, loading, error, reload } = useFetch('/doctor/stats'); useAuto(reload);
  if (loading && !s) return <Loader />;
  if (!s) return <ErrorBox msg={error} />;
  const t = s.today;
  const kpis = [['Today’s patients', t.total, 'hl'], ['New requests', s.pendingAll, 'warn'], ['Waiting now', t.waiting, ''], ['In consultation', t.inConsultation, ''], ['Completed today', t.completed, 'good'], ['Total patients treated', s.totalPatients, '']];
  const trend = s.trend.map((d) => ({ label: d.date.slice(5), total: d.total, completed: d.completed, remaining: Math.max(0, d.total - d.completed) }));
  const target = t.total || 1, pct = Math.round((t.completed / target) * 100);
  return (<div><h2>Welcome, {user.name}</h2><p className="muted" style={{ marginTop: -6 }}>{fmtDate(today())}</p>
    <div className="kpis k6">{kpis.map(([l, v, c]) => <div key={l} className={`card kpi ${c}`}><b>{v}</b><small>{l}</small></div>)}</div>
    <div className="card pad" style={{ marginBottom: 16 }}><div className="toolbar" style={{ margin: 0 }}><h3 style={{ margin: 0 }}>Today’s progress</h3><b>{t.completed} of {t.total} completed ({t.total ? pct : 0}%)</b></div><div className="progress" style={{ marginTop: 10, height: 12 }}><i style={{ width: `${t.total ? pct : 0}%` }} /></div>
      <p className="muted" style={{ margin: '8px 0 0' }}>{s.avgConsultMinutes ? `Average consultation: ${s.avgConsultMinutes} min • ` : ''}Upcoming (later dates): {s.upcoming} • Rejected today: {t.rejected}</p></div>
    <div className="chart-grid"><div className="card pad"><h3>Patients — last 14 days</h3><BarStack data={trend} series={[{ key: 'completed', color: '#12b76a', name: 'Completed' }, { key: 'remaining', color: '#c08a2e', name: 'Booked / not completed' }]} /></div>
      <div className="card pad"><h3>All appointments by status</h3><Donut parts={s.byStatus.map((b) => ({ label: NAMES[b.status], value: b.count, color: COLORS[b.status] }))} /></div></div>
    <div className="card pad"><h3>Completed consultations trend</h3><LineChart points={s.trend.map((d) => ({ label: d.date.slice(5), value: d.completed }))} color="#0b6b57" /></div></div>);
}

// ---------- Requests: accept (token + estimated time) or reject ----------
export function DoctorRequests() {
  const { data, loading, error, reload } = useFetch('/doctor/appointments?status=pending'); useAuto(reload, 15000);
  const [err, setErr] = useState(''); const [sel, setSel] = useState(null); const [est, setEst] = useState(''); const [note, setNote] = useState(''); const [busy, setBusy] = useState(false); const [msg, setMsg] = useState('');
  const open = (a, mode) => { setSel({ a, mode }); setEst(a.slot); setNote(''); setErr(''); setMsg(''); };
  const submit = async () => {
    setBusy(true); setErr('');
    try { const r = await api.put(`/doctor/appointments/${sel.a._id}/decision`, { action: sel.mode, estimatedTime: est, note }); setMsg(sel.mode === 'accept' ? `Accepted — Token #${r.data.token} generated, estimated ${fmtTime(r.data.estimatedTime)}.` : 'Request rejected.'); setSel(null); reload(); }
    catch (x) { setErr(errMsg(x)); } finally { setBusy(false); }
  };
  if (loading && !data) return <Loader />;
  return (<div><h2>Appointment requests</h2><p className="muted" style={{ marginTop: -6 }}>Accept to generate a token and estimated time for the patient, or reject with a reason.</p><ErrorBox msg={error || err} />{msg && <div className="ok" style={{ marginBottom: 12 }}>{msg}</div>}
    {!data?.length ? <Empty text="No pending requests. 🎉" /> : data.map((a) => <div key={a._id} className="card appt-card"><div className="appt-top"><div><b style={{ fontSize: 17 }}>{a.patientName}</b> <span className="muted">({a.patientAge} yrs) • {a.patientPhone}</span><div className="muted">Reason: {a.reason || '—'}</div></div><div style={{ textAlign: 'right' }}><b>{fmtDate(a.date)}</b><div className="muted">Requested {fmtTime(a.slot)}</div></div></div>
      <div className="actions"><button className="btn btn-sm btn-green" onClick={() => open(a, 'accept')}>Accept</button><button className="btn btn-sm btn-danger" onClick={() => open(a, 'reject')}>Reject</button></div></div>)}
    {sel && <div className="modal" onClick={() => setSel(null)}><div className="card" onClick={(e) => e.stopPropagation()}>
      <h3>{sel.mode === 'accept' ? 'Accept request' : 'Reject request'} — {sel.a.patientName}</h3>
      {sel.mode === 'accept' ? <div className="stack"><p className="muted" style={{ margin: 0 }}>A token number is generated automatically. Set the estimated time the patient should expect.</p><label className="l">Estimated consultation time<input type="time" value={est} onChange={(e) => setEst(e.target.value)} /></label><textarea rows="2" placeholder="Message to patient (optional)" value={note} onChange={(e) => setNote(e.target.value)} /></div>
        : <div className="stack"><textarea rows="3" placeholder="Reason (shown to the patient) e.g. doctor on leave — please book another day" value={note} onChange={(e) => setNote(e.target.value)} /></div>}
      <ErrorBox msg={err} /><div className="actions" style={{ marginTop: 12 }}><button className={`btn ${sel.mode === 'accept' ? 'btn-green' : 'btn-danger'}`} disabled={busy} onClick={submit}>{busy ? 'Saving…' : sel.mode === 'accept' ? 'Accept & generate token' : 'Reject request'}</button><button className="btn btn-outline" onClick={() => setSel(null)}>Cancel</button></div></div></div>}</div>);
}

// ---------- Queue: today's (or chosen date's) token list ----------
export function DoctorQueue() {
  const [date, setDate] = useState(today()); const { data, loading, error, reload } = useFetch(`/doctor/appointments?date=${date}`); useAuto(reload, 15000);
  const [err, setErr] = useState(''); const [open, setOpen] = useState(null); const EMPTY = { diagnosis: '', notes: '', meds: [{ medicine: '', dosage: '', duration: '' }] }; const [rec, setRec] = useState(EMPTY); const [msg, setMsg] = useState('');
  const act = async (id, status) => { setErr(''); try { await putStatus(id, { status }); reload(); } catch (e) { setErr(errMsg(e)); } };
  const saveRec = async (e) => {
    e.preventDefault(); setErr(''); setMsg('');
    if (!rec.diagnosis.trim()) return setErr('Diagnosis is required');
    try { await api.post('/records', { appointment: open, diagnosis: rec.diagnosis, notes: rec.notes, prescriptions: rec.meds.filter((m) => m.medicine.trim()) }); setMsg('Record saved'); setRec(EMPTY); } catch (x) { setErr(errMsg(x)); }
  };
  if (loading && !data) return <Loader />;
  const q = (data || []).filter((a) => ['accepted', 'in_consultation', 'completed', 'no_show'].includes(a.status)).sort((a, b) => (a.token || 99) - (b.token || 99));
  const waiting = q.filter((a) => a.status === 'accepted'); const nowIn = q.find((a) => a.status === 'in_consultation');
  const callNext = () => waiting[0] && act(waiting[0]._id, 'in_consultation');
  return (<div><div className="toolbar"><h2>Patient queue</h2><input type="date" value={date} onChange={(e) => setDate(e.target.value)} /></div><ErrorBox msg={error || err} />
    <div className="kpis"><div className="card kpi warn"><b>{waiting.length}</b><small>Waiting</small></div><div className="card kpi hl"><b>{nowIn ? `#${nowIn.token}` : '—'}</b><small>Now consulting</small></div><div className="card kpi good"><b>{q.filter((a) => a.status === 'completed').length}</b><small>Completed</small></div></div>
    <div style={{ marginBottom: 12 }}><button className="btn btn-green" disabled={!waiting.length || !!nowIn} onClick={callNext}>{nowIn ? 'Finish current patient first' : waiting.length ? `Call next: Token #${waiting[0].token}` : 'No one waiting'}</button></div>
    {!q.length ? <Empty text="No accepted patients for this date." /> : <div className="card">{q.map((a) => <div key={a._id} className="queue-row">
      <div className={`tk ${a.status === 'in_consultation' ? 'now' : ''}`}>{a.token}</div>
      <div><b>{a.patientName}</b> <span className="muted">({a.patientAge}) • {a.patientPhone}</span><div className="muted" style={{ fontSize: 13 }}>Est. {fmtTime(a.estimatedTime)} • {a.reason || 'No reason given'}</div></div>
      <div className="actions-col"><Status s={a.status} />
        {a.status === 'accepted' && <><button className="btn btn-sm" onClick={() => act(a._id, 'in_consultation')}>Start</button><button className="btn btn-sm btn-outline" onClick={() => confirm('Mark as no-show?') && act(a._id, 'no_show')}>No-show</button></>}
        {a.status === 'in_consultation' && <><button className="btn btn-sm btn-green" onClick={() => act(a._id, 'completed')}>Complete</button><button className="btn btn-sm btn-outline" onClick={() => { setOpen(open === a._id ? null : a._id); setMsg(''); }}>Notes & Rx</button></>}
        {a.status === 'completed' && <button className="btn btn-sm btn-outline" onClick={() => { setOpen(open === a._id ? null : a._id); setMsg(''); }}>Notes & Rx</button>}</div></div>)}</div>}
    {open && <form className="stack card pad" style={{ marginTop: 16 }} onSubmit={saveRec}><h3>Consultation notes & prescription</h3><input placeholder="Diagnosis" value={rec.diagnosis} onChange={(e) => setRec({ ...rec, diagnosis: e.target.value })} />
      <textarea rows="3" placeholder="Consultation notes" value={rec.notes} onChange={(e) => setRec({ ...rec, notes: e.target.value })} />
      {rec.meds.map((m, i) => <div className="two" key={i}>{[['medicine', 'Medicine'], ['dosage', 'Dosage (e.g. 1-0-1 after food)'], ['duration', 'Duration (e.g. 5 days)']].map(([k, ph]) => <input key={k} placeholder={ph} value={m[k]} onChange={(e) => setRec({ ...rec, meds: rec.meds.map((x, j) => (j === i ? { ...x, [k]: e.target.value } : x)) })} />)}</div>)}
      <div className="actions"><button type="button" className="btn btn-sm btn-outline" onClick={() => setRec({ ...rec, meds: [...rec.meds, { medicine: '', dosage: '', duration: '' }] })}>+ Add medicine</button>{rec.meds.length > 1 && <button type="button" className="btn btn-sm btn-outline" onClick={() => setRec({ ...rec, meds: rec.meds.slice(0, -1) })}>Remove last</button>}</div>
      {msg && <div className="ok">{msg}</div>}<button className="btn">Save record</button></form>}</div>);
}

// ---------- All appointments ----------
export function DoctorAppointments() {
  const [status, setStatus] = useState(''); const { data, loading, error } = useFetch(`/doctor/appointments${status ? `?status=${status}` : ''}`);
  if (loading && !data) return <Loader />;
  return (<div><div className="toolbar"><h2>All appointments</h2><select value={status} onChange={(e) => setStatus(e.target.value)}><option value="">All statuses</option>{Object.entries(NAMES).map(([k, v]) => <option key={k} value={k}>{v}</option>)}</select></div><ErrorBox msg={error} />
    {!data?.length ? <Empty /> : <div className="card scroll"><table className="tbl"><thead><tr><th>Date</th><th>Token</th><th>Est. time</th><th>Patient</th><th>Reason</th><th>Status</th></tr></thead><tbody>{[...data].reverse().map((a) => <tr key={a._id}><td>{fmtDate(a.date)}<br /><span className="muted">Req. {fmtTime(a.slot)}</span></td><td>{a.token ? `#${a.token}` : '—'}</td><td>{a.estimatedTime ? fmtTime(a.estimatedTime) : '—'}</td><td>{a.patientName} ({a.patientAge})<br /><span className="muted">{a.patientPhone}</span></td><td>{a.reason}</td><td><Status s={a.status} /></td></tr>)}</tbody></table></div>}</div>);
}

const ALL = ['09:00', '09:30', '10:00', '10:30', '11:00', '11:30', '12:00', '14:00', '14:30', '15:00', '16:00', '16:30', '17:00', '17:30'];
export function DoctorAvailability() {
  const { data, loading } = useFetch('/doctor/me'); const [av, setAv] = useState({}); const [msg, setMsg] = useState(''); const [err, setErr] = useState('');
  useEffect(() => { if (data) setAv(Object.fromEntries(data.availability.map((a) => [a.day, a.slots]))); }, [data]);
  const toggle = (d, t) => setAv((x) => { const cur = x[d] || []; return { ...x, [d]: cur.includes(t) ? cur.filter((y) => y !== t) : [...cur, t].sort() }; });
  const save = async () => {
    setMsg(''); setErr('');
    try { await api.put('/doctor/availability', { availability: Object.entries(av).filter(([, s]) => s.length).map(([day, slots]) => ({ day: Number(day), slots })) }); setMsg('Availability saved'); } catch (e) { setErr(errMsg(e)); }
  };
  if (loading) return <Loader />;
  return (<div><h2>Manage Availability</h2><p className="muted">Tap time slots to toggle them for each weekday.</p>
    {days.map((n, d) => <div key={d} className="card pad" style={{ marginBottom: 10 }}><b>{n}</b><div className="slots" style={{ marginTop: 8 }}>{ALL.map((t) => <button type="button" key={t} className={`slot ${(av[d] || []).includes(t) ? 'on' : ''}`} onClick={() => toggle(d, t)}>{fmtTime(t)}</button>)}</div></div>)}
    {err && <div className="error">{err}</div>}{msg && <div className="ok">{msg}</div>}<button className="btn" onClick={save}>Save availability</button></div>);
}
