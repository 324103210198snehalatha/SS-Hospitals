import { useEffect, useState } from 'react';
import { Link } from 'react-router-dom';
import useFetch from '../hooks/useFetch';
import api, { errMsg } from '../services/api';
import { useAuth } from '../context/AuthContext';
import { Loader, ErrorBox, Empty, Status, fmtDate, fmtTime, today } from '../components/UI';

// Live token / queue ticket shown for each appointment
function Ticket({ a }) {
  if (a.status === 'pending') return <div className="ticket pend"><div className="no" style={{ background: '#f79009' }}><small>TOKEN</small><b>—</b></div><div><b>Waiting for the doctor to accept</b><div className="muted">Requested time {fmtTime(a.slot)}. Your token and estimated time appear here once accepted.</div></div></div>;
  if (['accepted', 'in_consultation'].includes(a.status)) {
    const now = a.status === 'in_consultation'; const isToday = a.date === today();
    return (<div className="ticket"><div className="no"><small>TOKEN</small><b>{String(a.token).padStart(2, '0')}</b></div><div>
      {now ? <><b>It’s your turn — please go to the doctor’s room</b></> : <><b>Estimated time: {fmtTime(isToday && a.liveEstimate ? a.liveEstimate : a.estimatedTime)}</b>
        <div className="muted">{isToday ? <>Patients ahead of you: <b>{a.patientsAhead ?? 0}</b> • Please arrive 15 minutes early</> : <>On {fmtDate(a.date)} • Please arrive 15 minutes early</>}</div>
        {isToday && <div className="progress" style={{ marginTop: 8 }}><i style={{ width: `${Math.max(8, 100 - (a.patientsAhead || 0) * 20)}%` }} /></div>}</>}
      {a.decisionNote && <div className="muted" style={{ marginTop: 6 }}>Doctor’s note: {a.decisionNote}</div>}</div></div>);
  }
  if (a.status === 'rejected') return <div className="ticket rej"><div className="no" style={{ background: '#d92d20' }}><small>STATUS</small><b style={{ fontSize: 18 }}>✕</b></div><div><b>The doctor couldn’t accept this request</b><div className="muted">{a.decisionNote || 'Please choose another time or doctor.'}</div><Link to={`/book?doctor=${a.doctor?._id}`}>Book another slot →</Link></div></div>;
  return null;
}

export function PatientAppointments() {
  const { data, loading, error, reload } = useFetch('/appointments/mine'); const [err, setErr] = useState(''); const [tab, setTab] = useState('upcoming');
  useEffect(() => { const t = setInterval(reload, 15000); return () => clearInterval(t); }, [reload]); // keep token / queue fresh
  const cancel = async (id) => { if (!confirm('Cancel this appointment?')) return; try { await api.put(`/appointments/${id}/cancel`); reload(); } catch (e) { setErr(errMsg(e)); } };
  if (loading && !data) return <Loader />;
  const list = data || [];
  const live = (a) => ['pending', 'accepted', 'in_consultation'].includes(a.status) && a.date >= today();
  const up = list.filter(live), past = list.filter((a) => !live(a));
  const shown = tab === 'upcoming' ? up : past;
  const k = [['Upcoming', up.length, 'hl'], ['Awaiting doctor', list.filter((a) => a.status === 'pending').length, 'warn'], ['Accepted', list.filter((a) => a.status === 'accepted').length, ''], ['Completed', list.filter((a) => a.status === 'completed').length, 'good']];
  return (<div><div className="toolbar"><h2>My Appointments</h2><Link className="btn btn-sm" to="/book">Book new</Link></div><ErrorBox msg={error || err} />
    <div className="kpis">{k.map(([l, v, c]) => <div key={l} className={`card kpi ${c}`}><b>{v}</b><small>{l}</small></div>)}</div>
    <div className="tabs"><button className={tab === 'upcoming' ? 'on' : ''} onClick={() => setTab('upcoming')}>Upcoming ({up.length})</button><button className={tab === 'past' ? 'on' : ''} onClick={() => setTab('past')}>History ({past.length})</button></div>
    {!shown.length ? <Empty text={tab === 'upcoming' ? 'No upcoming appointments.' : 'No past appointments.'} /> : shown.map((a) => (
      <div className="card appt-card" key={a._id}>
        <div className="appt-top"><div><b style={{ fontSize: 17 }}>{a.doctor?.name}</b><div className="muted">{a.department?.name}</div></div><div style={{ textAlign: 'right' }}><Status s={a.status} /><div className="muted">{fmtDate(a.date)} • {fmtTime(a.slot)}</div></div></div>
        <Ticket a={a} />
        {['pending', 'accepted'].includes(a.status) && <div><button className="btn btn-sm btn-danger" onClick={() => cancel(a._id)}>Cancel appointment</button></div>}
      </div>))}
    <p className="muted" style={{ fontSize: 13 }}>This page refreshes automatically every 15 seconds.</p></div>);
}

export function PatientProfile() {
  const { user } = useAuth(); const { data, loading } = useFetch('/auth/me');
  const [f, setF] = useState({}); const [msg, setMsg] = useState(''); const [err, setErr] = useState('');
  useEffect(() => { if (data) setF({ name: data.name, phone: data.phone || '', gender: data.gender || '', dob: data.dob?.slice(0, 10) || '', address: data.address || '', bloodGroup: data.bloodGroup || '' }); }, [data]);
  const save = async (e) => {
    e.preventDefault(); setMsg(''); setErr('');
    if (!f.name?.trim()) return setErr('Name is required');
    try { await api.put('/auth/me', f); setMsg('Profile updated'); } catch (x) { setErr(errMsg(x)); }
  };
  if (loading) return <Loader />;
  const set = (k) => (e) => setF({ ...f, [k]: e.target.value });
  return (<div><h2>My Profile</h2><form className="stack card pad" onSubmit={save}><p className="muted">{user.email}</p>
    <input placeholder="Name" value={f.name || ''} onChange={set('name')} /><div className="two"><input placeholder="Phone" value={f.phone || ''} onChange={set('phone')} />
    <select value={f.gender || ''} onChange={set('gender')}><option value="">Gender</option><option>Male</option><option>Female</option><option>Other</option></select></div>
    <div className="two"><input type="date" value={f.dob || ''} onChange={set('dob')} /><input placeholder="Blood group" value={f.bloodGroup || ''} onChange={set('bloodGroup')} /></div>
    <textarea rows="2" placeholder="Address" value={f.address || ''} onChange={set('address')} />{err && <div className="error">{err}</div>}{msg && <div className="ok">{msg}</div>}<button className="btn">Save</button></form></div>);
}
export function PatientRecords({ onlyRx }) {
  const { data, loading, error } = useFetch('/records/mine');
  if (loading) return <Loader />;
  const list = onlyRx ? (data || []).filter((r) => r.prescriptions?.length) : data;
  return (<div><div className="toolbar"><h2>{onlyRx ? 'Prescription History' : 'Medical Records'}</h2>{!!list?.length && <button className="btn btn-sm btn-outline" onClick={() => window.print()}>Print</button>}</div><ErrorBox msg={error} />{!list?.length ? <Empty text="No records yet." /> : list.map((r) => <div key={r._id} className="card pad" style={{ marginBottom: 12 }}>
    <b>{r.doctor?.name}</b> <span className="muted">{new Date(r.createdAt).toLocaleDateString()}</span>
    {!onlyRx && <><p><b>Diagnosis:</b> {r.diagnosis}</p><p>{r.notes}</p></>}
    {r.prescriptions?.length > 0 && <ul>{r.prescriptions.map((p, i) => <li key={i}>{p.medicine} — {p.dosage} ({p.duration})</li>)}</ul>}</div>)}</div>);
}
