import { useEffect, useState } from 'react';
import { Link, NavLink, useNavigate } from 'react-router-dom';
import { Menu, X, HeartPulse } from 'lucide-react';
import { useAuth, dashboardPath } from '../context/AuthContext';

const LINKS = [
  ['Home', '/'], ['About Us', '/about'], ['Specialities', '/specialities'], ['Find a Doctor', '/doctors'], ['Hospitals', '/hospitals'],
  ['Health Check-up', '/health-checkup'], ['Patient Care', '/patient-care'], ['Health Library', '/health-library'], ['Contact Us', '/contact'],
];
export default function Navbar() {
  const [open, setOpen] = useState(false); const [scrolled, setScrolled] = useState(false);
  useEffect(() => { const on = () => setScrolled(window.scrollY > 8); on(); window.addEventListener('scroll', on, { passive: true }); return () => window.removeEventListener('scroll', on); }, []);
  const { user, logout } = useAuth();
  const nav = useNavigate();
  const close = () => setOpen(false);
  return (
    <header className={`navbar${scrolled ? ' scrolled' : ''}`}><div className="container nav-in">
      <Link to="/" className="brand" onClick={close}><span className="brand-mark"><HeartPulse size={20} /></span> <span>SS <b>HOSPITALS</b></span></Link>
      <button className="burger" aria-label="Menu" onClick={() => setOpen(!open)}>{open ? <X /> : <Menu />}</button>
      <nav className={open ? 'links open' : 'links'}>
        {LINKS.map(([t, to]) => <NavLink key={to} to={to} end={to === '/'} onClick={close}>{t}</NavLink>)}
        {user ? (
          <>
            <Link className="btn btn-sm" to={dashboardPath(user.role)} onClick={close}>Dashboard</Link>
            <button className="btn btn-outline btn-sm" onClick={() => { logout(); close(); nav('/'); }}>Logout</button>
          </>
        ) : <Link className="btn btn-sm" to="/login" onClick={close}>Login / Register</Link>}
      </nav>
    </div></header>
  );
}
