import { Component } from 'react';
// Shows the real error on screen instead of a blank white page.
export default class ErrorBoundary extends Component {
  state = { error: null };
  static getDerivedStateFromError(error) { return { error }; }
  componentDidCatch(error, info) { console.error('UI crash:', error, info?.componentStack); }
  render() {
    if (!this.state.error) return this.props.children;
    return (
      <div className="container center-msg">
        <h2>Something went wrong on this page</h2>
        <pre style={{ textAlign: 'left', whiteSpace: 'pre-wrap', background: '#fef3f2', color: '#b42318', padding: 16, borderRadius: 10 }}>{String(this.state.error?.stack || this.state.error)}</pre>
        <button className="btn" onClick={() => { this.setState({ error: null }); window.location.href = '/'; }}>Back to Home</button>
      </div>
    );
  }
}
