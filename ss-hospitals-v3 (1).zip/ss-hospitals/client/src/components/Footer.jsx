import { Link } from 'react-router-dom';
export default function Footer() {
  return (
    <footer className="footer"><div className="container foot-grid">
      <div><h4>SS HOSPITALS</h4><p>Smart Multispeciality Hospital. Compassionate care since 2007 — 8 branches across Andhra Pradesh and Telangana.</p><p>Emergency: <b>108</b></p></div>
      <div><h4>Quick Links</h4><Link to="/about">About Us</Link><Link to="/specialities">Specialities</Link><Link to="/doctors">Find a Doctor</Link><Link to="/hospitals">Hospitals</Link><Link to="/contact">Contact Us</Link></div>
      <div><h4>Patients</h4><Link to="/book">Book Appointment</Link><Link to="/health-checkup">Health Check-up</Link><Link to="/patient-care">Patient Care</Link><Link to="/health-library">Health Library</Link></div>
      <div><h4>Portals</h4><Link to="/login/patient">Patient Login</Link><Link to="/login/doctor">Doctor Login</Link><Link to="/register">New Patient Registration</Link><Link to="/login/admin">Admin</Link></div>
    </div><div className="copy">© {new Date().getFullYear()} SS Hospitals. Demonstration project — sample data. Health information is general and not a substitute for medical advice.</div></footer>
  );
}
