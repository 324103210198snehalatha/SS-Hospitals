// Small dependency-free SVG/CSS charts for the dashboards.
export function BarStack({ data, series }) { // data: [{label, a, b}] series: [{key,color,name}]
  const max = Math.max(1, ...data.map((d) => Math.max(d.total || 0, ...series.map((s) => d[s.key] || 0))));
  return (<div><div className="bars2">{data.map((d) => (
    <div className="col" key={d.label} title={`${d.label}: ` + series.map((s) => `${s.name} ${d[s.key] || 0}`).join(', ')}>
      <div className="stack" style={{ height: `${((d.total ?? d[series[0].key] ?? 0) / max) * 100}%` }}>
        {series.map((s) => <div key={s.key} style={{ background: s.color, height: `${d.total ? ((d[s.key] || 0) / d.total) * 100 : 0}%`, minHeight: d[s.key] ? 3 : 0 }} />)}
      </div><span>{d.label}</span></div>))}</div>
    <div className="legend">{series.map((s) => <span key={s.key}><i style={{ background: s.color }} />{s.name}</span>)}</div></div>);
}
export function Donut({ parts, size = 150, center }) { // parts: [{label,value,color}]
  const total = parts.reduce((a, p) => a + p.value, 0) || 1, r = 52, c = 2 * Math.PI * r; let off = 0;
  return (<div style={{ display: 'flex', gap: 18, alignItems: 'center', flexWrap: 'wrap' }}>
    <svg width={size} height={size} viewBox="0 0 140 140" role="img" aria-label="Donut chart">
      <circle cx="70" cy="70" r={r} fill="none" stroke="#eaecf0" strokeWidth="18" />
      {parts.filter((p) => p.value > 0).map((p) => { const len = (p.value / total) * c; const el = <circle key={p.label} cx="70" cy="70" r={r} fill="none" stroke={p.color} strokeWidth="18" strokeDasharray={`${len} ${c - len}`} strokeDashoffset={-off} transform="rotate(-90 70 70)" />; off += len; return el; })}
      <text x="70" y="68" textAnchor="middle" fontSize="22" fontWeight="800" fill="#073b32">{center ?? total}</text><text x="70" y="86" textAnchor="middle" fontSize="10" fill="#667085">total</text>
    </svg>
    <div className="legend" style={{ flexDirection: 'column', margin: 0 }}>{parts.map((p) => <span key={p.label}><i style={{ background: p.color }} />{p.label}: <b>{p.value}</b></span>)}</div></div>);
}
export function LineChart({ points, color = '#0b6b57', height = 150 }) { // points: [{label,value}]
  const w = 420, h = height, pad = 24, max = Math.max(1, ...points.map((p) => p.value));
  const xy = points.map((p, i) => [pad + (i * (w - pad * 2)) / Math.max(1, points.length - 1), h - pad - (p.value / max) * (h - pad * 2)]);
  const d = xy.map((p, i) => `${i ? 'L' : 'M'}${p[0].toFixed(1)},${p[1].toFixed(1)}`).join(' ');
  return (<svg viewBox={`0 0 ${w} ${h}`} width="100%" role="img" aria-label="Line chart">
    {[0, 0.5, 1].map((t) => <line key={t} x1={pad} x2={w - pad} y1={h - pad - t * (h - pad * 2)} y2={h - pad - t * (h - pad * 2)} stroke="#eaecf0" />)}
    <path d={`${d} L${xy.at(-1)[0]},${h - pad} L${xy[0][0]},${h - pad} Z`} fill={color} opacity=".08" />
    <path d={d} fill="none" stroke={color} strokeWidth="2.5" strokeLinejoin="round" />
    {xy.map((p, i) => <circle key={i} cx={p[0]} cy={p[1]} r="3.5" fill={color}><title>{points[i].label}: {points[i].value}</title></circle>)}
    {points.map((p, i) => (i % 2 === 0 || points.length < 8) && <text key={p.label} x={xy[i][0]} y={h - 6} textAnchor="middle" fontSize="9" fill="#667085">{p.label}</text>)}
  </svg>);
}
