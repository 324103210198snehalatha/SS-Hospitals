import { Phone, Siren, MapPin } from 'lucide-react';
export default function TopBar() {
  return (
    <div className="topbar"><div className="container topbar-in">
      <a href="tel:108"><Siren size={14} /> Emergency: 108</a>
      <a href="tel:+910000000000"><Phone size={14} /> +91 00000 00000 (sample)</a>
      <span><MapPin size={14} /> 8 branches • Andhra Pradesh & Telangana</span>
    </div></div>
  );
}
