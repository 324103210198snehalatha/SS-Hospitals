import { Link } from 'react-router-dom';
export const Loader = () => <div className="center-msg">Loading…</div>;
export const ErrorBox = ({ msg }) => msg ? <div className="error">{msg}</div> : null;
export const Empty = ({ text = 'Nothing found.' }) => <div className="empty">{text}</div>;
export const PageHead = ({ title, sub, crumb }) => (
  <section className="pagehead2"><div className="container">
    {crumb && <div className="crumbs"><Link to="/">Home</Link> › {crumb}</div>}
    <h1>{title}</h1>{sub && <p>{sub}</p>}
  </div></section>
);
// Colour avatar: a different gradient per doctor so profiles look distinct (replace with real photos when available)
const PALETTE = [['#0b6b57', '#073b32'], ['#0e9384', '#064e45'], ['#7a5af8', '#3e1c96'], ['#dd2590', '#851651'], ['#f79009', '#93370d'], ['#c08a2e', '#6b4a12'], ['#12b76a', '#054f31'], ['#e04f16', '#7a2e0e']];
export const hash = (s = '') => [...s].reduce((a, c) => (a * 31 + c.charCodeAt(0)) >>> 0, 7);
export const Avatar = ({ name = '?', size, photo }) => {
  const [c1, c2] = PALETTE[hash(name) % PALETTE.length];
  const ini = name.replace(/^Dr\.?\s*/, '').split(' ').map((w) => w[0]).slice(0, 2).join('');
  if (photo) return <img className={`avatar ${size || ''}`} src={photo} alt={name} style={{ objectFit: 'cover' }} />;
  return <div className={`avatar ${size || ''}`} style={{ '--c1': c1, '--c2': c2 }}>{ini}</div>;
};
export const STATUS_LABEL = { pending: 'Awaiting doctor', accepted: 'Accepted', in_consultation: 'In consultation', completed: 'Completed', rejected: 'Rejected', cancelled: 'Cancelled', no_show: 'No-show', confirmed: 'Accepted' };
export const Status = ({ s }) => <span className={`badge b-${s}`}>{STATUS_LABEL[s] || s}</span>;
export const days = ['Sun', 'Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat'];
export const availText = (d) => d.availability?.length ? d.availability.map((a) => days[a.day]).join(', ') : 'On request';
export const WeekStrip = ({ doctor }) => { const on = new Set((doctor.availability || []).filter((a) => a.slots?.length).map((a) => a.day)); return <div className="week">{days.map((x, i) => <div key={x} className={on.has(i) ? 'on' : ''}>{x}</div>)}</div>; };
export const today = () => new Date(Date.now() - new Date().getTimezoneOffset() * 60000).toISOString().slice(0, 10);
export const fmtDate = (d) => { try { return new Date(d + 'T00:00:00').toLocaleDateString('en-IN', { weekday: 'short', day: 'numeric', month: 'short', year: 'numeric' }); } catch { return d; } };
export const fmtTime = (t) => { if (!t) return '—'; const [h, m] = t.split(':').map(Number); return `${((h + 11) % 12) + 1}:${String(m).padStart(2, '0')} ${h >= 12 ? 'PM' : 'AM'}`; };
export const Tabs = ({ items, value, onChange }) => <div className="tabs">{items.map(([k, l]) => <button key={k} className={k === value ? 'on' : ''} onClick={() => onChange(k)}>{l}</button>)}</div>;
