import { HeartPulse, Brain, Bone, Baby, Eye, Ear, Stethoscope, Pill, Activity, Droplets, Scissors, Microscope, Smile, Wind, Syringe, Dumbbell, Siren, BedDouble, ShieldCheck, Users, Scale, Building2, Sparkles, Heart } from 'lucide-react';
const MAP = {
  cardiology: HeartPulse, neurology: Brain, oncology: Microscope, orthopaedics: Bone, gastroenterology: Pill, nephrology: Droplets, urology: Droplets,
  dermatology: Sparkles, paediatrics: Baby, gynaecology: Heart, pulmonology: Wind, endocrinology: Activity, ent: Ear, ophthalmology: Eye,
  'general-medicine': Stethoscope, 'general-surgery': Scissors, psychiatry: Smile, physiotherapy: Dumbbell,
};
export const specIcon = (slug) => MAP[slug] || Stethoscope;
export const CARE_ICONS = { Siren, BedDouble, ShieldCheck, Users, Scale, Building2 };
export { Syringe };
