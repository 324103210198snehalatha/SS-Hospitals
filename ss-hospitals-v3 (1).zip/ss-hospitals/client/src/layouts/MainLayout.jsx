import { Outlet, useLocation } from 'react-router-dom';
import { useEffect } from 'react';
import TopBar from '../components/TopBar';
import Navbar from '../components/Navbar';
import Footer from '../components/Footer';
import ErrorBoundary from '../components/ErrorBoundary';
export default function MainLayout() {
  const { pathname } = useLocation();
  useEffect(() => { window.scrollTo(0, 0); }, [pathname]);
  return <><TopBar /><Navbar /><main><ErrorBoundary key={pathname}><Outlet /></ErrorBoundary></main><Footer /></>;
}
