import { NavLink, Outlet, useNavigate } from 'react-router-dom';
import { LogOut } from 'lucide-react';
import { useAuth } from '../context/AuthContext';
import { Avatar } from '../components/UI';

// `theme` (patient | doctor | admin) gives every portal its own accent colour (see global.css).
export default function DashLayout({ links, title, theme = 'patient' }) {
  const { user, logout } = useAuth(); const nav = useNavigate();
  return (
    <div className={`dash-wrap theme-${theme}`}>
      <div className="container dash">
        <aside className="side card pad">
          <div className="side-user"><Avatar name={user?.name || '?'} /><div><b>{user?.name}</b><small>{title}</small></div></div>
          {links.map(([t, to, end]) => <NavLink key={to} to={to} end={end}>{t}</NavLink>)}
          <button className="side-out" onClick={() => { logout(); nav('/'); }}><LogOut size={16} /> Log out</button>
        </aside>
        <div className="dash-main"><Outlet /></div>
      </div>
    </div>
  );
}
