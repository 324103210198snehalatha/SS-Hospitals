import axios from 'axios';
const api = axios.create({ baseURL: import.meta.env.VITE_API_URL || 'http://localhost:5000/api' });
api.interceptors.request.use((cfg) => {
  const t = localStorage.getItem('ss_token');
  if (t) cfg.headers.Authorization = `Bearer ${t}`;
  return cfg;
});
export const errMsg = (e) => {
  if (e.response?.data?.message) return e.response.data.message;
  if (!e.response && (e.code === 'ERR_NETWORK' || e.message === 'Network Error')) return 'Cannot reach the server. Make sure the backend is running (cd server && npm run dev) and MongoDB is started.';
  return e.message || 'Something went wrong';
};
export default api;
