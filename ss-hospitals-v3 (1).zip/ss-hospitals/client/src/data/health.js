// General health information for education only — not a substitute for medical advice.
// SAMPLE CONTENT: have your doctors review before publishing.
const A = (slug, title, tag, read, summary, sections, when) => ({ slug, title, tag, read, summary, sections, when });

export const ARTICLES = [
  A('heart-health-basics', 'Heart health basics: 7 daily habits', 'Cardiology', 6, 'Small, steady habits protect your heart far more than occasional crash efforts.', [
    ['Move every day', 'Aim for at least 150 minutes of moderate activity each week — brisk walking, cycling or swimming. Even 30 minutes on most days lowers blood pressure and improves cholesterol.'],
    ['Eat for your heart', ['Fill half your plate with vegetables and fruit', 'Choose whole grains (millets, brown rice, oats) over refined flour', 'Use less salt, and limit pickles, papads and packaged snacks', 'Prefer groundnut, mustard or rice-bran oil in small amounts; avoid re-heated oil', 'Include fish, pulses, nuts and curd']],
    ['Quit tobacco', 'Smoking and chewing tobacco damage blood vessels within years. Quitting cuts heart-attack risk quickly, and it is never too late.'],
    ['Know your numbers', 'Check blood pressure, blood sugar and cholesterol regularly after 30. Many risk factors cause no symptoms until a major event.'],
    ['Sleep and stress', 'Seven to eight hours of sleep and regular relaxation — prayer, walks, hobbies, time with family — help keep blood pressure steady.'],
  ], 'Chest pain, breathlessness, sudden sweating or pain spreading to the arm or jaw — seek emergency care immediately.'),
  A('managing-diabetes', 'Managing diabetes day to day', 'Endocrinology', 7, 'Good control prevents most diabetes complications. Here is how to make it routine.', [
    ['Know your targets', 'Your doctor will set targets for fasting sugar, post-meal sugar and HbA1c. Write them down and review them at each visit.'],
    ['Plan your plate', ['Half the plate: non-starchy vegetables', 'A quarter: protein (dal, egg, fish, paneer, chicken)', 'A quarter: carbohydrate, preferably whole grain or millets', 'Avoid sugary drinks and sweets; fruit is fine in measured portions']],
    ['Stay active', 'A 20–30 minute walk after meals lowers sugar spikes. Add strength exercises twice a week.'],
    ['Take medicines correctly', 'Never stop or change insulin or tablets without asking your doctor. Carry a sugar source in case of low sugar.'],
    ['Protect eyes, feet and kidneys', 'Yearly eye examination, daily foot checks, and kidney tests (creatinine and urine albumin) catch problems early.'],
  ], 'Very high sugar with vomiting or confusion, or sugar below 70 mg/dL not improving with sugar, needs emergency care.'),
  A('child-vaccination', 'Child vaccination: why schedules matter', 'Paediatrics', 5, 'Vaccines protect your child at the age when infections are most dangerous.', [
    ['Why on time?', 'Vaccines are timed to protect babies when their immunity is weakest. Delays leave gaps in protection.'],
    ['What to expect', 'Mild fever, soreness or irritability for a day or two is common. Feed often and keep the baby comfortable.'],
    ['Keep a record', 'Keep the vaccination card safe and bring it to every visit. Your paediatrician can plan catch-up doses if any were missed.'],
  ], 'High fever that persists, a very sleepy child, a seizure, or breathing difficulty after a vaccine needs medical attention.'),
  A('healthy-pregnancy', 'A healthy pregnancy: antenatal care', 'Gynaecology', 7, 'Regular check-ups, good nutrition and rest help mother and baby.', [
    ['Start early', 'Begin antenatal care as soon as pregnancy is confirmed. Take folic acid as advised, ideally even before conceiving.'],
    ['Eat well', ['Extra iron- and calcium-rich foods: leafy greens, dates, ragi, milk, curd, eggs, pulses', 'Small, frequent meals if nauseous', 'Plenty of water', 'Avoid raw papaya, unpasteurised dairy, raw meat and alcohol']],
    ['Scans and tests', 'Blood tests, an early scan, an anomaly scan around 18–20 weeks, and a glucose test at 24–28 weeks are routine.'],
    ['Stay active', 'Walking and gentle prenatal exercises are usually safe unless your doctor advises rest.'],
  ], 'Bleeding, leaking fluid, severe headache, blurred vision, severe swelling or reduced baby movements — contact your doctor at once.'),
  A('joint-pain-relief', 'Joint pain: when to see a specialist', 'Orthopaedics', 5, 'Not all joint pain is arthritis — and most causes can be helped.', [
    ['Common causes', 'Wear-and-tear arthritis, injury, inflammatory arthritis, gout, low vitamin D, and overuse.'],
    ['What helps at home', ['Keep a healthy weight — each kilo lost removes about 4 kg of load from the knees', 'Stay active with low-impact exercise such as swimming or cycling', 'Heat for stiffness, cold for swelling', 'Strengthen thigh and hip muscles with physiotherapy']],
    ['Treatment ladder', 'Medicines and physiotherapy come first. Injections, arthroscopy or joint replacement are considered only when simpler measures fail.'],
  ], 'Hot, red, swollen joint with fever, inability to bear weight, or pain after injury needs prompt evaluation.'),
  A('mental-wellbeing', 'Looking after your mental wellbeing', 'Psychiatry', 5, 'Mental health is health. Small daily practices make a real difference.', [
    ['Daily foundations', ['Regular sleep and wake times', 'Daily movement and sunlight', 'Time with people you trust', 'Limit late-night screens and news']],
    ['Notice early signs', 'Persistent sadness, loss of interest, constant worry, irritability or withdrawal lasting more than two weeks deserve attention.'],
    ['Ask for help', 'Counselling and treatment work. Asking for help is a sign of strength, and consultations are confidential.'],
  ], 'Thoughts of self-harm need immediate help — go to the nearest hospital or call emergency services.'),
  A('blood-pressure-control', 'Controlling high blood pressure', 'General Medicine', 6, 'Hypertension is the “silent” risk factor behind many heart attacks and strokes.', [
    ['Why it matters', 'High blood pressure usually has no symptoms, yet silently damages the heart, brain, kidneys and eyes.'],
    ['Lifestyle first', ['Keep salt under about 5 g (one teaspoon) a day', 'Walk briskly for 30 minutes daily', 'Maintain a healthy weight and limit alcohol', 'Quit tobacco', 'Manage stress and sleep well']],
    ['Measure correctly', 'Sit quietly for 5 minutes, back supported, arm at heart level. Check at the same time daily and note readings for your doctor.'],
    ['Never skip medicines', 'Feeling fine does not mean pressure is controlled. Continue medicines unless your doctor changes them.'],
  ], 'Very high readings with headache, chest pain, vision change or weakness require emergency care.'),
  A('healthy-kidneys', 'Keeping your kidneys healthy', 'Nephrology', 5, 'Kidney damage is often silent. Prevention is simple.', [
    ['Protect them', ['Control diabetes and blood pressure', 'Drink water through the day unless restricted', 'Avoid regular painkillers (NSAIDs) without advice', 'Reduce salt and processed food', 'Do not smoke']],
    ['Get tested', 'A yearly creatinine and urine albumin test is advised for diabetics, hypertensives, and anyone over 50.'],
  ], 'Swelling, very little urine, or blood in urine needs prompt evaluation.'),
  A('eye-care', 'Caring for your eyes', 'Ophthalmology', 4, 'Simple habits prevent avoidable vision loss.', [
    ['Screen habits', 'Follow the 20-20-20 rule: every 20 minutes look at something 20 feet away for 20 seconds.'],
    ['Get checked', 'Annual eye tests for diabetics and everyone over 40; children should be screened before school age.'],
    ['Protect', 'Wear sunglasses outdoors and protective eyewear for work or sport. Never use eye drops without advice.'],
  ], 'Sudden vision loss, flashes of light, or eye injury is an emergency.'),
  A('healthy-lungs', 'Breathe easy: caring for your lungs', 'Pulmonology', 5, 'Clean air, no smoke and regular activity keep lungs strong.', [
    ['Avoid smoke', 'Tobacco, firewood smoke and dust are the commonest causes of chronic lung disease. Use a mask in dusty places.'],
    ['Asthma tips', ['Know your triggers: dust, smoke, cold, pollen', 'Use inhalers exactly as prescribed, with a spacer if advised', 'Keep a written action plan', 'Get a yearly flu vaccine if advised']],
    ['Stay fit', 'Walking and breathing exercises improve lung capacity.'],
  ], 'Severe breathlessness, blue lips or coughing blood needs emergency care.'),
  A('liver-health', 'Fatty liver: a modern epidemic', 'Gastroenterology', 5, 'Fatty liver is common and often reversible if caught early.', [
    ['Causes', 'Excess weight, diabetes, high cholesterol, sugary drinks and alcohol.'],
    ['What reverses it', ['Losing 5–10% of body weight', 'Cutting sweets, fried food and sugary drinks', 'Regular exercise', 'Avoiding alcohol']],
    ['Follow-up', 'Liver tests and an ultrasound or FibroScan show whether the liver is improving.'],
  ], 'Yellow eyes, black stools or vomiting blood need urgent care.'),
  A('first-aid', 'First aid every family should know', 'Emergency', 6, 'Knowing a few steps can save a life before help arrives.', [
    ['Bleeding', 'Press firmly with a clean cloth and raise the limb. Do not remove soaked cloth — add more on top.'],
    ['Burns', 'Cool with clean running water for 10–20 minutes. Do not apply toothpaste, oil or ice. Cover loosely with a clean cloth.'],
    ['Choking', 'For adults, give firm back blows then abdominal thrusts. Call for help immediately.'],
    ['Fainting', 'Lay the person flat, raise the legs, loosen tight clothing and check breathing. Call emergency if not awake in a minute.'],
    ['Call early', 'Dial 108 first in any serious situation.'],
  ], 'When in doubt, call emergency services.'),
];

// ---------------- Diet guides ----------------
export const DIETS = {
  diabetes: { title: 'Diabetes — daily diet guide', note: 'A general sample. Portions and calories must be personalised by your doctor or dietitian.',
    plan: [['Early morning', '1 glass warm water; 4–5 soaked almonds or 1 tsp soaked methi seeds'], ['Breakfast', '2 small vegetable-stuffed rotis / 2 idlis with sambar / vegetable upma / besan chilla with mint chutney + 1 cup tea or coffee without sugar'], ['Mid-morning', '1 small fruit (guava, apple, papaya) or a cup of buttermilk'], ['Lunch', '1 cup cooked millet/brown rice or 2 rotis + 1 cup dal + 2 cups vegetables + salad + 1 cup curd'], ['Evening', 'Roasted chana / sprouts chaat / unsweetened tea with a handful of nuts'], ['Dinner', 'Early and light: 2 rotis or vegetable millet khichdi + vegetable curry + salad'], ['Bedtime', 'Warm turmeric milk (unsweetened), if advised']],
    eat: ['Non-starchy vegetables (gourds, beans, leafy greens, cabbage)', 'Millets: ragi, jowar, bajra, foxtail', 'Pulses, sprouts, eggs, fish, skinless chicken', 'Nuts and seeds in small portions', 'Whole fruit (not juice)'],
    limit: ['Sugar, jaggery, sweets, cool drinks, fruit juices', 'White rice / maida in large portions', 'Potato, sweet potato, banana, mango in large quantities', 'Fried snacks, bakery items', 'Skipping meals, then overeating'] },
  heart: { title: 'Heart-healthy diet guide', note: 'General guidance. Follow your cardiologist’s advice, especially after a heart event.',
    plan: [['Early morning', 'Warm water with lemon; a handful of walnuts or almonds'], ['Breakfast', 'Oats / ragi malt / vegetable upma / 2 idlis with sambar + 1 fruit'], ['Mid-morning', 'Coconut water or buttermilk'], ['Lunch', '2 rotis or 1 cup brown rice + dal + 2 cups vegetables + salad + curd'], ['Evening', 'Green tea + roasted chana or fruit'], ['Dinner', 'Light: vegetable soup + 2 rotis + grilled fish or paneer + vegetables']],
    eat: ['Fruit, vegetables, leafy greens', 'Whole grains and millets', 'Pulses, nuts, seeds', 'Fish (grilled or curry, not fried) twice a week', 'Low-fat milk and curd'],
    limit: ['Salt, pickles, papad, chips, instant noodles', 'Fried foods and trans-fats (bakery, vanaspati)', 'Red and processed meat', 'Sugary drinks and sweets', 'Excess alcohol'] },
  kidney: { title: 'Kidney-friendly diet guide', note: 'Kidney diets differ by stage. Always get a plan from your nephrologist or renal dietitian.',
    plan: [['Breakfast', 'Idli/dosa with limited sambar + egg white omelette'], ['Mid-morning', 'Apple or papaya (small portion, as advised)'], ['Lunch', 'White rice or roti + limited dal + low-potassium vegetables (cabbage, cauliflower, bottle gourd) + curd as advised'], ['Evening', 'Unsalted biscuits or puffed rice'], ['Dinner', 'Roti + vegetable curry + egg white or measured protein']],
    eat: ['Low-potassium vegetables: cabbage, cauliflower, bottle gourd, ridge gourd', 'Apple, papaya, pear in measured portions', 'Egg whites and measured high-quality protein', 'Fluids exactly as advised'],
    limit: ['Salt and salty foods', 'High-potassium foods: banana, tender coconut, potato, tomato, oranges (if advised)', 'Packaged and processed foods', 'Cola drinks', 'Herbal or over-the-counter remedies without advice'] },
  weight: { title: 'Healthy weight-loss diet guide', note: 'Aim for gradual loss of 0.5 kg a week. Avoid crash diets.',
    plan: [['Early morning', 'Warm water; green tea'], ['Breakfast', 'Protein-rich: moong dal chilla / egg + vegetables / idli with sambar / oats upma'], ['Mid-morning', 'Fruit or buttermilk'], ['Lunch', 'Half plate vegetables, quarter dal/protein, quarter rice or roti + salad'], ['Evening', 'Sprouts, roasted chana, or cucumber-carrot sticks'], ['Dinner', 'Early (before 8 pm): soup + salad + 1–2 rotis + protein']],
    eat: ['Vegetables and salads at every meal', 'Protein: dal, egg, fish, chicken, paneer, sprouts', 'Whole grains in measured portions', 'Plenty of water'],
    limit: ['Sugary drinks and sweets', 'Fried and bakery snacks', 'Late-night eating', 'Large rice portions', 'Skipping meals'] },
};

// ---------------- Child growth (approximate WHO medians) ----------------
export const GROWTH = {
  note: 'Approximate median values based on WHO child growth standards. Healthy children vary — a child a little above or below these numbers is often perfectly normal. Your paediatrician will plot your child on a growth chart.',
  rows: [ // age, boy wt, boy ht, girl wt, girl ht
    ['Birth', 3.3, 49.9, 3.2, 49.1], ['3 months', 6.4, 61.4, 5.8, 59.8], ['6 months', 7.9, 67.6, 7.3, 65.7], ['9 months', 8.9, 72.0, 8.2, 70.1], ['1 year', 9.6, 75.7, 8.9, 74.0],
    ['2 years', 12.2, 87.1, 11.5, 85.7], ['3 years', 14.3, 96.1, 13.9, 95.1], ['4 years', 16.3, 103.3, 15.9, 102.7], ['5 years', 18.3, 110.0, 17.7, 109.4],
    ['6 years', 20.5, 116.0, 19.5, 115.1], ['7 years', 22.9, 121.7, 21.8, 120.8], ['8 years', 25.4, 127.3, 24.8, 126.6], ['9 years', 28.1, 132.6, 28.2, 132.5], ['10 years', 31.2, 137.8, 31.9, 138.6],
  ],
  milestones: [['2 months', 'Smiles socially, follows objects with eyes'], ['4 months', 'Holds head steady, laughs, reaches for toys'], ['6 months', 'Rolls over, sits with support, babbles'], ['9 months', 'Sits alone, crawls, responds to name'], ['12 months', 'Stands with support, says 1–2 words, waves bye'], ['18 months', 'Walks alone, says several words, points to show'], ['2 years', 'Runs, combines two words, follows simple instructions'], ['3 years', 'Speaks in short sentences, pedals tricycle, plays with others'], ['5 years', 'Hops, draws a person, counts, dresses with little help']],
};

// ---------------- Pregnancy care ----------------
export const PREGNANCY = {
  trimesters: [
    { name: 'First trimester', weeks: 'Weeks 1–12', body: 'Nausea, tiredness and breast tenderness are common. The baby’s organs are forming.', tips: ['Start folic acid and prenatal vitamins as advised', 'Book your first antenatal visit and early scan', 'Eat small, frequent meals; sip fluids', 'Avoid alcohol, tobacco and unprescribed medicines', 'Get adequate rest'], tests: ['Blood group & Rh', 'Haemoglobin', 'Blood sugar', 'Thyroid', 'Urine tests', 'Early dating scan'] },
    { name: 'Second trimester', weeks: 'Weeks 13–27', body: 'Energy usually returns and the baby’s movements begin around week 18–20.', tips: ['Take iron and calcium as prescribed', 'Walk daily and do gentle exercises', 'Sleep on your side', 'Eat leafy greens, pulses, dairy, fruits', 'Attend monthly check-ups'], tests: ['Anomaly (level II) scan at 18–20 weeks', 'Glucose tolerance test at 24–28 weeks', 'Repeat haemoglobin', 'Blood pressure checks'] },
    { name: 'Third trimester', weeks: 'Weeks 28–40', body: 'The baby gains weight rapidly. You may feel breathless, swollen or tired.', tips: ['Count baby movements daily', 'Visit every 2 weeks, then weekly near term', 'Pack your hospital bag by week 36', 'Learn labour signs; plan transport', 'Discuss delivery options with your doctor'], tests: ['Growth scan', 'Blood pressure and urine protein', 'Fetal heart monitoring', 'Presentation check near term'] },
  ],
  warning: ['Vaginal bleeding or fluid leakage', 'Severe or persistent headache, blurred vision', 'Sudden swelling of face or hands', 'Severe abdominal pain', 'Reduced or absent baby movements', 'Fever or painful urination', 'Persistent vomiting'],
};

// ---------------- Vaccination (India-style schedule; sample) ----------------
export const VACCINES = {
  note: 'Based on the general Indian immunisation schedule. Exact vaccines and timing may vary — follow your paediatrician’s advice.',
  rows: [['Birth', 'BCG, OPV-0, Hepatitis B (birth dose)'], ['6 weeks', 'DPT/Pentavalent-1, OPV-1, Rotavirus-1, PCV-1, IPV-1'], ['10 weeks', 'DPT/Pentavalent-2, OPV-2, Rotavirus-2'], ['14 weeks', 'DPT/Pentavalent-3, OPV-3, Rotavirus-3, PCV-2, IPV-2'], ['9 months', 'Measles-Rubella (MR-1), PCV booster (as advised)'], ['12 months', 'Hepatitis A, Typhoid conjugate (as advised)'], ['16–24 months', 'DPT booster-1, OPV booster, MR-2'], ['5–6 years', 'DPT booster-2'], ['10 years', 'Td / Tdap'], ['16 years', 'Td']],
};

// ---------------- Reference ranges ----------------
export const RANGES = [
  ['Blood pressure', 'Below 120/80 mmHg', '120–129 / <80 elevated; 130/80 or more = hypertension range'],
  ['Fasting blood sugar', '70–99 mg/dL', '100–125 pre-diabetes; 126 or more diabetes range'],
  ['HbA1c', 'Below 5.7%', '5.7–6.4% pre-diabetes; 6.5% or more diabetes range'],
  ['Total cholesterol', 'Below 200 mg/dL', '200–239 borderline; 240 or more high'],
  ['LDL (“bad”) cholesterol', 'Below 100 mg/dL', 'Targets are lower in people with heart disease'],
  ['HDL (“good”) cholesterol', '40 mg/dL or more (men), 50 or more (women)', 'Higher is better'],
  ['Triglycerides', 'Below 150 mg/dL', '150–199 borderline; 200 or more high'],
  ['BMI (Asian cut-offs)', '18.5–22.9 kg/m²', '23–24.9 overweight; 25 or more obese'],
  ['Resting heart rate', '60–100 beats/min', 'Athletes may be lower'],
  ['Haemoglobin', '13–17 g/dL (men), 12–15 g/dL (women)', 'Lower values suggest anaemia'],
  ['Vitamin D', '30–100 ng/mL', 'Below 20 = deficiency'],
  ['TSH', '0.4–4.0 mIU/L', 'Interpretation depends on age and pregnancy'],
];
