import { Routes, Route } from 'react-router-dom';
import MainLayout from './layouts/MainLayout';
import DashLayout from './layouts/DashLayout';
import ProtectedRoute from './components/ProtectedRoute';
import Home from './pages/Home';
import { LoginChooser, Login, Register } from './pages/AuthPages';
import { Specialities, SpecialityDetail } from './pages/Specialities';
import { Services, ServiceDetail } from './pages/Services';
import { Doctors, DoctorProfile } from './pages/Doctors';
import { About, Hospitals, HealthCheckup, Contact } from './pages/Info';
import { HealthLibrary, Article } from './pages/HealthLibrary';
import PatientCare from './pages/PatientCare';
import Book from './pages/Book';
import { PatientAppointments, PatientProfile, PatientRecords } from './pages/Patient';
import { DoctorHome, DoctorRequests, DoctorQueue, DoctorAppointments, DoctorAvailability } from './pages/DoctorPortal';
import { AdminHome, AdminAppointments, AdminPatients, AdminInquiries, AdminCrud, ADMIN_RESOURCES } from './pages/Admin';

const patientLinks = [['Appointments', '/patient', true], ['Medical Records', '/patient/records'], ['Prescriptions', '/patient/prescriptions'], ['Profile', '/patient/profile']];
const doctorLinks = [['Overview', '/doctor', true], ['Requests', '/doctor/requests'], ['Patient Queue', '/doctor/queue'], ['All Appointments', '/doctor/appointments'], ['Availability', '/doctor/availability']];
const adminLinks = [['Overview', '/admin', true], ['Appointments', '/admin/appointments'], ['Patients', '/admin/patients'], ...Object.entries(ADMIN_RESOURCES).map(([k, r]) => [r.title, `/admin/${k}`]), ['Messages', '/admin/messages']];

export default function App() {
  return (
    <Routes>
      <Route element={<MainLayout />}>
        <Route index element={<Home />} />
        <Route path="login" element={<LoginChooser />} />
        <Route path="login/:role" element={<Login />} />
        <Route path="register" element={<Register />} />
        <Route path="about" element={<About />} />
        <Route path="specialities" element={<Specialities />} />
        <Route path="specialities/:slug" element={<SpecialityDetail />} />
        <Route path="patient-care" element={<PatientCare />} />
        <Route path="patient-care/:section" element={<PatientCare />} />
        <Route path="services" element={<Services />} />
        <Route path="services/:slug" element={<ServiceDetail />} />
        <Route path="doctors" element={<Doctors />} />
        <Route path="doctors/:id" element={<DoctorProfile />} />
        <Route path="hospitals" element={<Hospitals />} />
        <Route path="health-checkup" element={<HealthCheckup />} />
        <Route path="health-library" element={<HealthLibrary />} />
        <Route path="health-library/:slug" element={<Article />} />
        <Route path="contact" element={<Contact />} />
        <Route path="book" element={<Book />} />

        <Route path="patient" element={<ProtectedRoute roles={['patient']}><DashLayout title="Patient Portal" theme="patient" links={patientLinks} /></ProtectedRoute>}>
          <Route index element={<PatientAppointments />} /><Route path="records" element={<PatientRecords />} /><Route path="prescriptions" element={<PatientRecords onlyRx />} /><Route path="profile" element={<PatientProfile />} />
        </Route>
        <Route path="doctor" element={<ProtectedRoute roles={['doctor']}><DashLayout title="Doctor Desk" theme="doctor" links={doctorLinks} /></ProtectedRoute>}>
          <Route index element={<DoctorHome />} /><Route path="requests" element={<DoctorRequests />} /><Route path="queue" element={<DoctorQueue />} /><Route path="appointments" element={<DoctorAppointments />} /><Route path="availability" element={<DoctorAvailability />} />
        </Route>
        <Route path="admin" element={<ProtectedRoute roles={['admin']}><DashLayout title="Hospital Admin" theme="admin" links={adminLinks} /></ProtectedRoute>}>
          <Route index element={<AdminHome />} /><Route path="appointments" element={<AdminAppointments />} /><Route path="patients" element={<AdminPatients />} /><Route path="messages" element={<AdminInquiries />} />
          {Object.entries(ADMIN_RESOURCES).map(([k, r]) => <Route key={k} path={k} element={<AdminCrud key={k} {...r} />} />)}
        </Route>
        <Route path="*" element={<div className="container center-msg"><h2>Page not found</h2><a href="/">Back to Home</a></div>} />
      </Route>
    </Routes>
  );
}
