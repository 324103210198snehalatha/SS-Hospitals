import { useCallback, useEffect, useState } from 'react';
import api, { errMsg } from '../services/api';
export default function useFetch(url) {
  const [data, setData] = useState(null); const [loading, setLoading] = useState(!!url); const [error, setError] = useState('');
  const load = useCallback(() => {
    if (!url) { setData(null); setLoading(false); return; }
    setLoading(true);
    api.get(url).then((r) => { setData(r.data); setError(''); }).catch((e) => setError(errMsg(e))).finally(() => setLoading(false));
  }, [url]);
  useEffect(load, [load]);
  return { data, loading, error, reload: load };
}
