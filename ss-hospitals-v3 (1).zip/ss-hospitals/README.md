# SS HOSPITALS — Smart Multispeciality Hospital Management System (v3)
MERN app: React (Vite) client + Express/MongoDB server.

## Run (needs Node 18+ and MongoDB running)
Server: cd server && cp .env.example .env && npm i && npm run seed && npm run dev   (http://localhost:5000)
Client: cd client && cp .env.example .env && npm i && npm run dev                    (http://localhost:5173)

IMPORTANT: run `npm run seed` again after upgrading — it rebuilds the database (new doctor fields, 8 branches, new appointment statuses/indexes).

## Sample logins (created by the seed script — sample data only)
Admin:   /login/admin    admin@sshospitals.test    / Admin@123
Patient: /login/patient  patient@sshospitals.test  / Patient@123
Doctor:  /login/doctor   doctor1@sshospitals.test  / Doctor@123   (doctor1 … doctor36)

## What changed in v3
- NEW colour theme: deep emerald + gold on warm ivory (no more all-blue site). Serif headings (Playfair Display), refined buttons, cards, navbar, footer.
- Each portal has its own accent colour: Patient = emerald, Doctor = teal, Admin = bronze/gold. Sidebar now shows the signed-in user and a Log out button.
- DOCTOR LOGIN FIXED (several causes):
  - Server: emails are now trimmed + lower-cased before lookup (a capital letter from a phone keyboard failed before).
  - Server: a doctor login whose profile was not linked (old database seeded before v2) is auto-linked by name; otherwise a clear message is shown.
  - Client: if another account (e.g. admin/patient) was still signed in, /login/doctor silently redirected you away — now it tells you and offers "Log out & continue".
  - Client: after login you always land on your own dashboard (stale redirect to another role's page removed); wrong-role visitors are sent to their own dashboard instead of Home.
  - Friendly "Cannot reach the server" message; server refuses to start without .env (clear message); CORS accepts any localhost port (Vite 5174 etc.).
  - Login page: show/hide password, "fill demo account" button.
- Doctor: prescriptions can now have several medicines. Patient: Print button on records/prescriptions (print-friendly layout).
- Remember: if the doctor login still says "Invalid email or password", run `npm run seed` again in /server, then try doctor1@sshospitals.test / Doctor@123.

## What changed in v2
- Home page redesigned (hero, quick search, emergency strip, why-us, specialities, doctors, how-it-works, packages, story, stats, locations, library, news, testimonials, FAQ)
- About Us: full founders' story, timeline, mission/vision/values
- Specialities: rich detail pages (conditions, symptoms, treatments, tests, facilities, FAQs, doctors, booking sidebar)
- Find a Doctor: 36 unique doctors, distinct profiles (designation, education, expertise, languages, weekly availability, fee), filters incl. gender
- Hospitals: 8 branches with beds, highlights, timings, directions
- Health Check-up: 8 packages by category, tests list, savings, booking form (saved as an enquiry)
- Patient Care: 6 real sections (Emergency, Admission & Discharge, Insurance & Billing, Visitors, Patient Rights, Facilities)
- Health Library: 12 long articles, diet plans (diabetes/heart/kidney/weight), child growth table + milestones + vaccination schedule, pregnancy care by trimester, BMI / due-date / water calculators, normal-range table, A–Z conditions
- Separate logins: /login/patient, /login/doctor, /login/admin (server rejects wrong-role logins)
- Appointment workflow: Patient sends request (pending) -> Doctor accepts (token + estimated time generated) or rejects (with reason) -> Doctor runs the queue (Start / Complete / No-show) -> Patient sees token, estimated time and patients-ahead live (auto-refresh)
- Doctor Desk: overview counts (today's patients, new requests, waiting, completed, total patients), 14-day chart, status donut, completion trend, requests inbox, patient queue with "Call next", all appointments, availability
- Fixed: slot-uniqueness index now uses an `active` flag (MongoDB partial indexes cannot use $ne)

## Notes
- Articles, news, testimonials, FAQs, founder bios, addresses and prices are SAMPLE content — replace with verified content. Medical content should be reviewed by your doctors before publishing.
- No photos are bundled (avoids licensing issues); doctors show coloured initials avatars. Add a `photo` URL on a doctor to show a real image.
- Not yet run end-to-end in the build environment (no network/MongoDB there): run the steps above and report any error.
