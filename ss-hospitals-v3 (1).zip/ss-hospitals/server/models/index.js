import mongoose from 'mongoose';
import bcrypt from 'bcryptjs';
const { Schema, model } = mongoose;
const opts = { timestamps: true };

const userSchema = new Schema({
  name: { type: String, required: true, trim: true },
  email: { type: String, required: true, unique: true, lowercase: true },
  password: { type: String, required: true, minlength: 6, select: false },
  phone: String, gender: String, dob: Date, address: String, bloodGroup: String,
  role: { type: String, enum: ['patient', 'doctor', 'admin'], default: 'patient' },
}, opts);
userSchema.pre('save', async function (next) {
  if (this.isModified('password')) this.password = await bcrypt.hash(this.password, 10);
  next();
});
userSchema.methods.matches = function (p) { return bcrypt.compare(p, this.password); };
export const User = model('User', userSchema);

export const Department = model('Department', new Schema({
  name: { type: String, required: true, unique: true }, description: String, icon: String,
}, opts));

export const Speciality = model('Speciality', new Schema({
  name: { type: String, required: true, unique: true }, slug: { type: String, unique: true },
  intro: String, treatments: [String], facilities: [String], image: String, conditions: [String],
  department: { type: Schema.Types.ObjectId, ref: 'Department' },
}, opts));

export const Branch = model('Branch', new Schema({
  name: { type: String, required: true }, city: String, state: String, address: String, phone: String, emergencyPhone: String,
  beds: Number, timings: String, highlights: [String], mapUrl: String, isMain: { type: Boolean, default: false },
}, opts));

export const Doctor = model('Doctor', new Schema({
  user: { type: Schema.Types.ObjectId, ref: 'User' },
  name: { type: String, required: true }, qualification: String, designation: String, experience: Number, photo: String, bio: String, fee: { type: Number, default: 500 },
  gender: String, languages: [String], expertise: [String], awards: [String], education: [String],
  department: { type: Schema.Types.ObjectId, ref: 'Department', required: true },
  speciality: { type: Schema.Types.ObjectId, ref: 'Speciality', required: true },
  branch: { type: Schema.Types.ObjectId, ref: 'Branch' },
  availability: [{ day: Number, slots: [String] }], // day: 0=Sun..6=Sat
}, opts));

const appointmentSchema = new Schema({
  patient: { type: Schema.Types.ObjectId, ref: 'User', required: true },
  doctor: { type: Schema.Types.ObjectId, ref: 'Doctor', required: true },
  department: { type: Schema.Types.ObjectId, ref: 'Department' },
  date: { type: String, required: true }, // YYYY-MM-DD
  slot: { type: String, required: true }, // requested time, e.g. 10:30
  patientName: String, patientAge: Number, patientPhone: String, reason: String,
  // pending -> accepted | rejected ; accepted -> in_consultation -> completed ; also cancelled / no_show
  status: { type: String, enum: ['pending', 'accepted', 'in_consultation', 'completed', 'rejected', 'cancelled', 'no_show'], default: 'pending' },
  token: Number,              // generated when the doctor accepts (per doctor, per date)
  estimatedTime: String,      // HH:MM, set by the doctor on accept (defaults to requested slot)
  decisionNote: String,       // reason for rejection / message to patient
  decidedAt: Date, startedAt: Date, completedAt: Date,
  notes: String,
  active: { type: Boolean, default: true }, // false once cancelled / rejected / no_show -> frees the slot
}, opts);
// One live booking per doctor/date/slot. (Mongo partial indexes can't use $ne, so we use an `active` flag.)
appointmentSchema.index({ doctor: 1, date: 1, slot: 1 }, { unique: true, partialFilterExpression: { active: true } });
appointmentSchema.index({ doctor: 1, date: 1, token: 1 });
export const Appointment = model('Appointment', appointmentSchema);

export const MedicalRecord = model('MedicalRecord', new Schema({
  patient: { type: Schema.Types.ObjectId, ref: 'User', required: true },
  doctor: { type: Schema.Types.ObjectId, ref: 'Doctor' },
  appointment: { type: Schema.Types.ObjectId, ref: 'Appointment' },
  diagnosis: String, notes: String,
  prescriptions: [{ medicine: String, dosage: String, duration: String }],
}, opts));

export const Service = model('Service', new Schema({
  title: { type: String, required: true }, slug: { type: String, unique: true }, summary: String, details: String, image: String,
}, opts));

export const HealthPackage = model('HealthPackage', new Schema({
  name: { type: String, required: true }, price: Number, tests: [String], description: String, suitableFor: String,
  category: String, popular: Boolean, fasting: String, reportTime: String, homeCollection: Boolean, originalPrice: Number,
}, opts));

export const Inquiry = model('Inquiry', new Schema({
  type: { type: String, enum: ['contact', 'newsletter', 'callback', 'package'], default: 'contact' },
  name: String, email: String, phone: String, message: String,
}, opts));
