// SAMPLE DEMONSTRATION DATA ONLY — not real doctors, patients, addresses or prices.
import 'dotenv/config';
import mongoose from 'mongoose';
import { User, Department, Speciality, Branch, Doctor, Service, HealthPackage, Appointment, MedicalRecord, Inquiry } from '../models/index.js';

const slug = (s) => s.toLowerCase().replace(/[^a-z0-9]+/g, '-').replace(/(^-|-$)/g, '');
const SPECS = {
  Cardiology: ['Angioplasty', 'Bypass surgery', 'Echocardiography', 'Pacemaker implantation'],
  Neurology: ['Stroke care', 'Epilepsy management', 'EEG & EMG', 'Migraine treatment'],
  Oncology: ['Chemotherapy', 'Radiation therapy', 'Cancer surgery', 'Immunotherapy'],
  Orthopaedics: ['Joint replacement', 'Arthroscopy', 'Fracture care', 'Spine surgery'],
  Gastroenterology: ['Endoscopy', 'Colonoscopy', 'Liver disease care', 'IBD treatment'],
  Nephrology: ['Dialysis', 'Kidney stone management', 'CKD care', 'Transplant evaluation'],
  Urology: ['Prostate care', 'Laser stone removal', 'Urologic oncology', 'Male infertility'],
  Dermatology: ['Acne & skin care', 'Laser treatments', 'Allergy testing', 'Hair disorders'],
  Paediatrics: ['Newborn care', 'Vaccination', 'Growth monitoring', 'Paediatric emergency'],
  Gynaecology: ['Antenatal care', 'Normal & C-section delivery', 'Fertility care', 'Laparoscopic surgery'],
  Pulmonology: ['Asthma & COPD care', 'Bronchoscopy', 'Sleep studies', 'Pulmonary function tests'],
  Endocrinology: ['Diabetes management', 'Thyroid care', 'Hormonal disorders', 'Obesity management'],
  ENT: ['Sinus surgery', 'Hearing evaluation', 'Tonsillectomy', 'Voice disorders'],
  Ophthalmology: ['Cataract surgery', 'Retina care', 'Glaucoma treatment', 'LASIK evaluation'],
  'General Medicine': ['Fever & infections', 'Hypertension care', 'Chronic disease follow-up', 'Health screening'],
  'General Surgery': ['Hernia repair', 'Appendectomy', 'Gallbladder surgery', 'Minimally invasive surgery'],
  Psychiatry: ['Counselling', 'Depression & anxiety care', 'De-addiction', 'Child psychiatry'],
  Physiotherapy: ['Rehabilitation', 'Sports injury care', 'Post-surgery recovery', 'Neuro-physiotherapy'],
};
const CONDITIONS = {
  Cardiology: ['Coronary artery disease', 'Heart attack', 'Heart failure', 'Arrhythmia', 'Hypertension', 'Valve disease'],
  Neurology: ['Stroke', 'Epilepsy', 'Migraine', 'Parkinson’s disease', 'Neuropathy', 'Vertigo'],
  Oncology: ['Breast cancer', 'Oral cancer', 'Lung cancer', 'Colorectal cancer', 'Cervical cancer', 'Blood cancers'],
  Orthopaedics: ['Arthritis', 'Fractures', 'Ligament injuries', 'Slip disc', 'Osteoporosis', 'Frozen shoulder'],
  Gastroenterology: ['Acid reflux / GERD', 'Gastritis & ulcers', 'Fatty liver', 'Hepatitis', 'Pancreatitis', 'IBS'],
  Nephrology: ['Chronic kidney disease', 'Kidney stones', 'Nephrotic syndrome', 'Acute kidney injury', 'Diabetic kidney disease', 'Dialysis care'],
  Urology: ['Kidney & ureteric stones', 'Enlarged prostate', 'UTI', 'Urinary incontinence', 'Prostate cancer', 'Male infertility'],
  Dermatology: ['Acne', 'Eczema', 'Psoriasis', 'Fungal infections', 'Hair loss', 'Pigmentation'],
  Paediatrics: ['Fever & infections', 'Asthma in children', 'Growth problems', 'Neonatal jaundice', 'Diarrhoea', 'Vaccination needs'],
  Gynaecology: ['Pregnancy care', 'PCOS', 'Fibroids', 'Menstrual disorders', 'Infertility', 'Menopause'],
  Pulmonology: ['Asthma', 'COPD', 'Pneumonia', 'Tuberculosis', 'Sleep apnoea', 'Interstitial lung disease'],
  Endocrinology: ['Type 1 & 2 diabetes', 'Thyroid disorders', 'PCOS', 'Obesity', 'Pituitary disorders', 'Osteoporosis'],
  ENT: ['Sinusitis', 'Tonsillitis', 'Hearing loss', 'Ear infections', 'Snoring', 'Vocal cord problems'],
  Ophthalmology: ['Cataract', 'Glaucoma', 'Diabetic retinopathy', 'Dry eye', 'Refractive errors', 'Squint'],
  'General Medicine': ['Fever & infections', 'Diabetes', 'Hypertension', 'Typhoid & dengue', 'Thyroid', 'Anaemia'],
  'General Surgery': ['Hernia', 'Appendicitis', 'Gallstones', 'Piles & fissure', 'Thyroid lumps', 'Varicose veins'],
  Psychiatry: ['Depression', 'Anxiety', 'Sleep problems', 'Addiction', 'OCD', 'Child behaviour issues'],
  Physiotherapy: ['Back & neck pain', 'Post-fracture rehab', 'Stroke rehab', 'Sports injuries', 'Joint stiffness', 'Balance problems'],
};
const SERVICES = [
  ['General Consultation', 'Outpatient consultations with experienced physicians across all specialities, with same-day diagnostics.', ['Appointments with token & estimated time', 'Follow-up consultations', 'Second-opinion visits', 'Digital prescriptions in your patient portal']],
  ['Emergency Services', 'A 24x7 emergency department with trauma, cardiac and stroke readiness and ambulance support.', ['24x7 emergency physicians', 'Ambulance with life support', 'Trauma & cardiac care bays', 'Direct ICU access']],
  ['Laboratory and Diagnostic Services', 'A fully equipped laboratory offering routine and specialised tests with fast reporting.', ['Biochemistry, haematology, microbiology', 'Home sample collection (selected areas)', 'Online reports', 'Quality-checked processes']],
  ['Radiology and Imaging', 'Digital X-ray, ultrasound, CT and MRI services with specialist radiologist reporting.', ['Digital X-ray & Ultrasound', 'CT scan', 'MRI', 'Mammography & bone density']],
  ['Surgical Services', 'Modular operation theatres for general, laparoscopic, orthopaedic and super-speciality surgeries.', ['Modular OTs', 'Minimally invasive surgery', 'Day-care surgery', 'Post-operative recovery wards']],
  ['Maternity and Childcare', 'Complete antenatal, delivery and newborn care with a dedicated neonatal unit.', ['Antenatal clinics', 'Normal & C-section delivery', 'NICU support', 'Lactation guidance & vaccination']],
  ['Physiotherapy and Rehabilitation', 'Therapist-led rehabilitation after surgery, stroke, injury and for chronic pain.', ['Orthopaedic rehab', 'Neuro-rehabilitation', 'Sports injury care', 'Home-exercise programmes']],
  ['Pharmacy Services', 'In-house pharmacy open round the clock with genuine medicines and prescription support.', ['24x7 pharmacy', 'Medicine counselling', 'Refill reminders', 'Billing at discharge']],
  ['Intensive Care Services', 'Medical, surgical and cardiac ICUs with continuous monitoring by intensivists.', ['Intensivist-led ICU', 'Ventilator support', 'Central monitoring', 'Family update protocol']],
  ['Mental Health Services', 'Confidential counselling, psychiatric care and de-addiction support for all ages.', ['Counselling & therapy', 'Psychiatric consultation', 'De-addiction programme', 'Child & adolescent support']],
];
const BRANCHES = [
  ['SS Hospitals — Kakinada (Main)', 'Kakinada', 'Andhra Pradesh', 400, true, ['24x7 emergency', 'Cath lab', 'Level-III NICU', 'Cancer centre']],
  ['SS Hospitals — Rajahmundry', 'Rajahmundry', 'Andhra Pradesh', 220, false, ['24x7 emergency', 'Maternity wing', 'Dialysis unit', 'Day-care surgery']],
  ['SS Hospitals — Visakhapatnam', 'Visakhapatnam', 'Andhra Pradesh', 300, false, ['Trauma centre', 'MRI & CT', 'Cardiac ICU', 'Robotic-ready OT']],
  ['SS Hospitals — Vijayawada', 'Vijayawada', 'Andhra Pradesh', 260, false, ['24x7 emergency', 'Neuro care', 'Orthopaedic centre', 'Pharmacy 24x7']],
  ['SS Hospitals — Guntur', 'Guntur', 'Andhra Pradesh', 180, false, ['Maternity & paediatrics', 'Diagnostics', 'ICU', 'Physiotherapy']],
  ['SS Hospitals — Tirupati', 'Tirupati', 'Andhra Pradesh', 200, false, ['Emergency & trauma', 'Gastro centre', 'Dialysis', 'Health check-up centre']],
  ['SS Hospitals — Nellore', 'Nellore', 'Andhra Pradesh', 150, false, ['24x7 emergency', 'General surgery', 'Diagnostics', 'Pharmacy 24x7']],
  ['SS Hospitals — Hyderabad', 'Hyderabad', 'Telangana', 350, false, ['Multi-organ ICU', 'Transplant evaluation', 'Oncology', 'International patient desk']],
];
const DOCTORS = [
  ['Anitha Rao', 'F'], ['Ravi Kumar Varma', 'M'], ['Meera Nair', 'F'], ['Suresh Babu Chowdary', 'M'], ['Lakshmi Prasanna', 'F'], ['Karthik Reddy', 'M'],
  ['Divya Menon', 'F'], ['Arjun Raghavan', 'M'], ['Padmaja Sri', 'F'], ['Venkata Ramana', 'M'], ['Sandhya Devi', 'F'], ['Mohan Krishna Murthy', 'M'],
  ['Nisha Thomas', 'F'], ['Prakash Naidu', 'M'], ['Swathi Pothula', 'F'], ['Harish Chandra Raju', 'M'], ['Kavya Sharma', 'F'], ['Rajesh Iyer', 'M'],
  ['Bhavana Kolli', 'F'], ['Naveen Gopal', 'M'], ['Haritha Yadav', 'F'], ['Srinivas Pillai', 'M'], ['Madhavi Latha', 'F'], ['Gautam Bhaskar', 'M'],
  ['Pooja Agarwal', 'F'], ['Chaitanya Dasari', 'M'], ['Rekha Subramanian', 'F'], ['Dinesh Kumar Patnaik', 'M'], ['Sirisha Gandham', 'F'], ['Vikram Singh Rathore', 'M'],
  ['Anusha Chintala', 'F'], ['Tarun Mehta', 'M'], ['Jyothi Kiran', 'F'], ['Ashok Vardhan', 'M'], ['Sowmya Bhat', 'F'], ['Imran Sheikh', 'M'],
];
const SENIOR = ['Senior Consultant', 'Consultant', 'Associate Consultant', 'HOD & Senior Consultant'];
const LANGS = [['Telugu', 'English', 'Hindi'], ['Telugu', 'English'], ['English', 'Hindi', 'Tamil'], ['Telugu', 'English', 'Kannada'], ['English', 'Hindi', 'Urdu'], ['Telugu', 'Hindi']];
const SLOTS = ['09:00', '09:30', '10:00', '10:30', '11:00', '11:30', '16:00', '16:30', '17:00', '17:30'];
const COLLEGES = ['Andhra Medical College, Visakhapatnam', 'Osmania Medical College, Hyderabad', 'Guntur Medical College', 'Kakatiya Medical College', 'Government Medical College, Kakinada', 'Sri Venkateswara Institute of Medical Sciences', 'Kurnool Medical College', 'Gandhi Medical College'];

await mongoose.connect(process.env.MONGO_URI);
await Promise.all([User, Department, Speciality, Branch, Doctor, Service, HealthPackage, Appointment, MedicalRecord, Inquiry].map((m) => m.deleteMany({})));
try { await Appointment.collection.dropIndexes(); } catch { /* collection may not exist yet */ }
await Appointment.syncIndexes();

await User.create({ name: 'SS Admin', email: 'admin@sshospitals.test', password: 'Admin@123', role: 'admin' });
await User.create({ name: 'Sample Patient', email: 'patient@sshospitals.test', password: 'Patient@123', role: 'patient', phone: '9876543210' });

const branches = await Branch.insertMany(BRANCHES.map(([name, city, state, beds, isMain, highlights], i) => ({
  name, city, state, beds, isMain, highlights, timings: 'OPD 9:00 AM – 8:00 PM • Emergency 24x7',
  address: `Sample address, ${city}, ${state}`, phone: `0${800 + i}-000${1000 + i}`, emergencyPhone: '108 / 0' + (800 + i) + '-000108',
})));

let n = 0;
for (const [name, treatments] of Object.entries(SPECS)) {
  const dept = await Department.create({ name: `${name} Department`, description: `Care and treatment in ${name}.` });
  const spec = await Speciality.create({
    name, slug: slug(name), department: dept._id, treatments, conditions: CONDITIONS[name],
    intro: `Our ${name} team provides comprehensive, evidence-based care with modern diagnostics and compassionate follow-up.`,
    facilities: ['Dedicated outpatient clinic', 'Advanced diagnostics', 'Modular operation theatres', '24x7 emergency support'],
  });
  for (let i = 0; i < 2; i++) {
    const [dn, gender] = DOCTORS[n % DOCTORS.length];
    const email = `doctor${n + 1}@sshospitals.test`;
    const exp = 7 + ((n * 7) % 24);
    const post = i ? `DNB (${name})` : `MD / MS (${name})`;
    const user = await User.create({ name: `Dr. ${dn}`, email, password: 'Doctor@123', role: 'doctor', gender: gender === 'F' ? 'Female' : 'Male' });
    await Doctor.create({
      user: user._id, name: `Dr. ${dn}`, gender, designation: SENIOR[(n + i) % SENIOR.length] + `, ${name}`,
      qualification: `MBBS, ${post}`, experience: exp, fee: 400 + ((n * 3) % 7) * 100,
      department: dept._id, speciality: spec._id, branch: branches[n % branches.length]._id,
      languages: LANGS[n % LANGS.length], expertise: treatments.slice(i, i + 3), education: [`MBBS — ${COLLEGES[n % COLLEGES.length]}`, `${post} — ${COLLEGES[(n + 3) % COLLEGES.length]}`],
      bio: `Dr. ${dn} is a ${SENIOR[(n + i) % SENIOR.length].toLowerCase()} in ${name} with ${exp} years of experience, with a special interest in ${treatments[i].toLowerCase()} and ${treatments[(i + 2) % 4].toLowerCase()}. Known for clear explanations and patient-first care. (Sample demonstration profile.)`,
      availability: [1, 2, 3, 4, 5, 6].map((day) => ({ day, slots: (day + n) % 3 === 0 ? SLOTS.slice(4) : (day + n) % 3 === 1 ? SLOTS.slice(0, 6) : SLOTS })),
    });
    n++;
  }
}
await Service.insertMany(SERVICES.map(([t, summary, points]) => ({ title: t, slug: slug(t), summary, details: points.join('\n') })));
await HealthPackage.insertMany([
  { name: 'Basic Health Check', category: 'General', price: 1499, originalPrice: 1999, suitableFor: 'Adults 18+', fasting: '10–12 hours', reportTime: 'Same day', homeCollection: true, tests: ['CBC', 'Fasting blood sugar', 'Lipid profile', 'Urine routine', 'Blood pressure & BMI'] },
  { name: 'Executive Health Check', category: 'General', popular: true, price: 3999, originalPrice: 5200, suitableFor: 'Adults 30+', fasting: '10–12 hours', reportTime: 'Same day', homeCollection: false, tests: ['CBC', 'LFT', 'KFT', 'Thyroid profile', 'HbA1c', 'Lipid profile', 'ECG', 'Chest X-ray', 'Physician consultation'] },
  { name: 'Senior Citizen Check', category: 'Senior', price: 4999, originalPrice: 6500, suitableFor: 'Age 60+', fasting: '10–12 hours', reportTime: 'Same day', homeCollection: true, tests: ['Full blood panel', 'HbA1c', 'ECG', '2D Echo', 'Bone density', 'Eye screening', 'Vitamin D & B12', 'Physician consultation'] },
  { name: 'Women’s Wellness Check', category: 'Women', popular: true, price: 4499, originalPrice: 5800, suitableFor: 'Women 25+', fasting: '10–12 hours', reportTime: 'Within 24 hours', homeCollection: false, tests: ['CBC', 'Thyroid profile', 'Pap smear', 'Mammography / breast ultrasound', 'Vitamin D', 'Iron studies', 'Gynaecologist consultation'] },
  { name: 'Heart Care Check', category: 'Cardiac', price: 5499, originalPrice: 7000, suitableFor: 'Anyone with heart risk factors', fasting: '10–12 hours', reportTime: 'Same day', homeCollection: false, tests: ['Lipid profile', 'HbA1c', 'ECG', '2D Echo', 'Treadmill test (TMT)', 'hs-CRP', 'Cardiologist consultation'] },
  { name: 'Diabetes Care Check', category: 'Diabetes', price: 2999, originalPrice: 3800, suitableFor: 'Diabetics & pre-diabetics', fasting: '8–10 hours', reportTime: 'Same day', homeCollection: true, tests: ['Fasting & post-meal sugar', 'HbA1c', 'Kidney function', 'Urine microalbumin', 'Lipid profile', 'Foot & eye screening', 'Diet counselling'] },
  { name: 'Men’s Wellness Check', category: 'Men', price: 4299, originalPrice: 5500, suitableFor: 'Men 35+', fasting: '10–12 hours', reportTime: 'Same day', homeCollection: false, tests: ['CBC', 'LFT', 'KFT', 'Lipid profile', 'PSA', 'Thyroid profile', 'ECG', 'Ultrasound abdomen'] },
  { name: 'Child Growth Check', category: 'Child', price: 1299, originalPrice: 1700, suitableFor: 'Children 2–12 yrs', fasting: 'Not required', reportTime: 'Same day', homeCollection: true, tests: ['CBC', 'Vitamin D & B12', 'Thyroid screening', 'Growth & BMI assessment', 'Vision screening', 'Paediatrician consultation'] },
]);
console.log(`Seeded sample data: ${n} doctors, ${branches.length} branches. Logins: admin@sshospitals.test / Admin@123, patient@sshospitals.test / Patient@123, doctor1@sshospitals.test / Doctor@123`);
await mongoose.disconnect();
