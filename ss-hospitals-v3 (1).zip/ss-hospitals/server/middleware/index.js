import jwt from 'jsonwebtoken';
import { validationResult } from 'express-validator';
import { User } from '../models/index.js';

export const protect = async (req, res, next) => {
  const h = req.headers.authorization;
  if (!h?.startsWith('Bearer ')) return res.status(401).json({ message: 'Not authenticated' });
  try {
    const { id } = jwt.verify(h.split(' ')[1], process.env.JWT_SECRET);
    req.user = await User.findById(id);
    if (!req.user) throw new Error();
    next();
  } catch { res.status(401).json({ message: 'Invalid or expired token' }); }
};
export const allow = (...roles) => (req, res, next) =>
  roles.includes(req.user.role) ? next() : res.status(403).json({ message: 'Access denied' });
export const validate = (req, res, next) => {
  const e = validationResult(req);
  if (!e.isEmpty()) return res.status(422).json({ message: e.array()[0].msg, errors: e.array() });
  next();
};
export const notFound = (req, res) => res.status(404).json({ message: `Route ${req.originalUrl} not found` });
export const errorHandler = (err, req, res, _next) => {
  let status = res.statusCode >= 400 ? res.statusCode : 500, message = err.message;
  if (err.code === 11000) { status = 409; message = 'Already exists, or that slot is already booked'; }
  if (err.name === 'ValidationError' || err.name === 'CastError') status = 400;
  res.status(status).json({ message });
};
export const wrap = (fn) => (req, res, next) => Promise.resolve(fn(req, res, next)).catch(next);
