import { Router } from 'express';
import { protect, allow, validate, wrap } from '../middleware/index.js';
import { body } from 'express-validator';
import { Department, Speciality, Branch, Service, HealthPackage, Doctor, Inquiry } from '../models/index.js';
import * as auth from '../controllers/auth.js';
import * as doc from '../controllers/doctors.js';
import * as appt from '../controllers/appointments.js';
import * as admin from '../controllers/admin.js';

const r = Router();
const adminOnly = [protect, allow('admin')];

// Auth
r.post('/auth/register', auth.registerRules, validate, auth.register);
r.post('/auth/login', auth.loginRules, validate, auth.login);
r.get('/auth/me', protect, auth.me);
r.put('/auth/me', protect, auth.updateMe);

// Generic CRUD: public read, admin write
const crud = (path, Model, populate = '') => {
  r.get(path, wrap(async (q, s) => s.json(await Model.find().populate(populate).sort('createdAt'))));
  r.get(`${path}/:id`, wrap(async (q, s) => {
    const m = q.params.id.length === 24 ? await Model.findById(q.params.id).populate(populate) : await Model.findOne({ slug: q.params.id }).populate(populate);
    m ? s.json(m) : s.status(404).json({ message: 'Not found' });
  }));
  r.post(path, adminOnly, wrap(async (q, s) => s.status(201).json(await Model.create(q.body))));
  r.put(`${path}/:id`, adminOnly, wrap(async (q, s) => s.json(await Model.findByIdAndUpdate(q.params.id, q.body, { new: true, runValidators: true }))));
  r.delete(`${path}/:id`, adminOnly, wrap(async (q, s) => { await Model.findByIdAndDelete(q.params.id); s.json({ ok: true }); }));
};
crud('/departments', Department);
crud('/specialities', Speciality, 'department');
crud('/branches', Branch);
crud('/services', Service);
crud('/packages', HealthPackage);

// Doctors
r.get('/doctors', doc.listDoctors);
r.get('/doctors/:id', doc.getDoctor);
r.get('/doctors/:id/slots', doc.doctorSlots);
r.post('/doctors', adminOnly, wrap(admin.createDoctor));
r.put('/doctors/:id', adminOnly, wrap(async (q, s) => s.json(await Doctor.findByIdAndUpdate(q.params.id, q.body, { new: true }))));
r.delete('/doctors/:id', adminOnly, wrap(async (q, s) => { await Doctor.findByIdAndDelete(q.params.id); s.json({ ok: true }); }));
r.get('/doctor/me', protect, allow('doctor'), doc.doctorMe);
r.put('/doctor/availability', protect, allow('doctor'), doc.myAvailability);

// Appointments
r.post('/appointments', protect, allow('patient'), appt.bookRules, validate, appt.book);
r.get('/appointments/mine', protect, allow('patient'), appt.mine);
r.put('/appointments/:id/cancel', protect, allow('patient'), appt.cancel);
r.get('/doctor/appointments', protect, allow('doctor'), appt.doctorAppointments);
r.put('/doctor/appointments/:id/decision', protect, allow('doctor'), appt.decide);
r.get('/doctor/stats', protect, allow('doctor'), appt.doctorStats);
r.put('/appointments/:id/status', protect, allow('doctor', 'admin'), appt.setStatus);

// Medical records
r.get('/records/mine', protect, allow('patient'), appt.myRecords);
r.post('/records', protect, allow('doctor'), appt.addRecord);

// Admin
r.get('/admin/stats', ...adminOnly, admin.stats);
r.get('/admin/patients', ...adminOnly, admin.listPatients);
r.delete('/admin/users/:id', ...adminOnly, admin.deleteUser);
r.get('/admin/appointments', ...adminOnly, admin.allAppointments);

r.delete('/admin/appointments/:id', ...adminOnly, admin.deleteAppointment);
r.get('/admin/inquiries', ...adminOnly, admin.inquiries);

// Public: contact form, callback request, newsletter
r.post('/inquiries', [body('type').isIn(['contact', 'newsletter', 'callback', 'package']).withMessage('Invalid type'),
  body('email').optional({ checkFalsy: true }).isEmail().withMessage('Valid email required'),
  body('name').if(body('type').equals('contact')).trim().notEmpty().withMessage('Name is required'),
  body('message').if(body('type').equals('contact')).trim().notEmpty().withMessage('Message is required')], validate,
  wrap(async (q, s) => { const { type, name, email, phone, message } = q.body; await Inquiry.create({ type, name, email, phone, message }); s.status(201).json({ ok: true }); }));

export default r;
