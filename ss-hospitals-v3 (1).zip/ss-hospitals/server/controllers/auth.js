import jwt from 'jsonwebtoken';
import { body } from 'express-validator';
import { User, Doctor } from '../models/index.js';
import { wrap } from '../middleware/index.js';

const sign = (u) => jwt.sign({ id: u._id }, process.env.JWT_SECRET, { expiresIn: process.env.JWT_EXPIRES || '7d' });
const out = (u) => ({ id: u._id, name: u.name, email: u.email, role: u.role, phone: u.phone });

export const registerRules = [
  body('name').trim().notEmpty().withMessage('Name is required'),
  body('email').isEmail().withMessage('Valid email required'),
  body('password').isLength({ min: 6 }).withMessage('Password must be at least 6 characters'),
  body('phone').optional({ checkFalsy: true }).isMobilePhone().withMessage('Invalid phone number'),
];
export const loginRules = [body('email').isEmail().withMessage('Valid email required'), body('password').notEmpty().withMessage('Password required')];

export const register = wrap(async (req, res) => {
  const { name, password, phone, gender, dob } = req.body;
  const email = String(req.body.email || '').trim().toLowerCase();
  if (await User.findOne({ email })) { res.status(409); throw new Error('Email already registered'); }
  const u = await User.create({ name, email, password, phone, gender, dob, role: 'patient' }); // public signup is always patient
  res.status(201).json({ token: sign(u), user: out(u) });
});
// Link a doctor login to its Doctor profile. Seeded/admin-created doctors are already linked by `user`;
// older databases (seeded before the `user` link existed) are healed here by matching the profile name.
async function ensureDoctorProfile(u) {
  let d = await Doctor.findOne({ user: u._id });
  if (!d) {
    d = await Doctor.findOne({ name: u.name, $or: [{ user: { $exists: false } }, { user: null }] });
    if (d) { d.user = u._id; await d.save(); }
  }
  return d;
}

// Separate portals: the login page for a role only accepts accounts of that role.
export const login = wrap(async (req, res) => {
  const role = req.body.role;
  const email = String(req.body.email || '').trim().toLowerCase(); // emails are stored lowercase; phones/keyboards often capitalise
  const password = String(req.body.password || '');
  const u = await User.findOne({ email }).select('+password');
  if (!u || !(await u.matches(password))) { res.status(401); throw new Error('Invalid email or password'); }
  if (role && u.role !== role) { res.status(403); throw new Error(`This account is a ${u.role} account, not a ${role} account. Please use the ${u.role} login page.`); }
  if (u.role === 'doctor' && !(await ensureDoctorProfile(u))) {
    res.status(403); throw new Error('Your doctor profile is not set up yet. Please ask the hospital admin (or re-run `npm run seed`).');
  }
  res.json({ token: sign(u), user: out(u) });
});
export const me = wrap(async (req, res) => res.json(req.user));
export const updateMe = wrap(async (req, res) => {
  const { name, phone, gender, dob, address, bloodGroup } = req.body;
  Object.assign(req.user, { name, phone, gender, dob, address, bloodGroup });
  await req.user.save();
  res.json(req.user);
});
