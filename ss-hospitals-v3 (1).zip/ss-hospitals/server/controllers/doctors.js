import { Doctor, Appointment } from '../models/index.js';
import { wrap } from '../middleware/index.js';

export const listDoctors = wrap(async (req, res) => {
  const { q, speciality, department, branch } = req.query, f = {};
  if (q) f.name = new RegExp(q.replace(/[.*+?^${}()|[\]\\]/g, '\\$&'), 'i');
  if (speciality) f.speciality = speciality;
  if (department) f.department = department;
  if (branch) f.branch = branch;
  res.json(await Doctor.find(f).populate('department speciality branch').sort('name'));
});
export const getDoctor = wrap(async (req, res) => {
  const d = await Doctor.findById(req.params.id).populate('department speciality branch');
  if (!d) { res.status(404); throw new Error('Doctor not found'); }
  res.json(d);
});
// Available slots for a doctor on a date (YYYY-MM-DD) = weekly availability minus booked slots
export const doctorSlots = wrap(async (req, res) => {
  const { date } = req.query;
  if (!/^\d{4}-\d{2}-\d{2}$/.test(date || '')) { res.status(400); throw new Error('date (YYYY-MM-DD) required'); }
  const d = await Doctor.findById(req.params.id);
  if (!d) { res.status(404); throw new Error('Doctor not found'); }
  const day = new Date(date + 'T00:00:00').getDay();
  const base = d.availability.find((a) => a.day === day)?.slots || [];
  const booked = (await Appointment.find({ doctor: d._id, date, active: true })).map((a) => a.slot);
  const now = new Date(Date.now() - new Date().getTimezoneOffset() * 60000).toISOString();
  const isToday = date === now.slice(0, 10), nowMin = new Date().getHours() * 60 + new Date().getMinutes();
  const mins = (t) => { const [h, m] = t.split(':').map(Number); return h * 60 + m; };
  res.json({ date, slots: base.filter((s) => !booked.includes(s) && (!isToday || mins(s) > nowMin)) });
});
export const myAvailability = wrap(async (req, res) => {
  const d = await Doctor.findOneAndUpdate({ user: req.user._id }, { availability: req.body.availability }, { new: true });
  if (!d) { res.status(404); throw new Error('Doctor profile not found'); }
  res.json(d);
});
export const doctorMe = wrap(async (req, res) => {
  const d = await Doctor.findOne({ user: req.user._id }).populate('department speciality branch');
  if (!d) { res.status(404); throw new Error('Doctor profile not found'); }
  res.json(d);
});
