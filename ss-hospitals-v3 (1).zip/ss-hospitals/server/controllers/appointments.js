import { body } from 'express-validator';
import { Appointment, Doctor, MedicalRecord } from '../models/index.js';
import { wrap } from '../middleware/index.js';

const LIVE = ['pending', 'accepted', 'in_consultation', 'completed'];
const todayStr = () => new Date(Date.now() - new Date().getTimezoneOffset() * 60000).toISOString().slice(0, 10);
const hhmm = (d = new Date()) => `${String(d.getHours()).padStart(2, '0')}:${String(d.getMinutes()).padStart(2, '0')}`;
const toMin = (t) => { const [h, m] = String(t).split(':').map(Number); return h * 60 + (m || 0); };
const fromMin = (n) => `${String(Math.floor(n / 60)).padStart(2, '0')}:${String(n % 60).padStart(2, '0')}`;
const AVG_CONSULT_MIN = 15;

export const bookRules = [
  body('doctor').isMongoId().withMessage('Select a doctor'),
  body('date').matches(/^\d{4}-\d{2}-\d{2}$/).withMessage('Select a date'),
  body('slot').notEmpty().withMessage('Select a time slot'),
  body('patientName').trim().notEmpty().withMessage('Patient name required'),
  body('patientAge').isInt({ min: 0, max: 120 }).withMessage('Valid age required'),
  body('patientPhone').isMobilePhone().withMessage('Valid phone required'),
];

// 1) PATIENT sends a request -> status "pending". Doctor must accept before a token is issued.
export const book = wrap(async (req, res) => {
  const { doctor, date, slot, patientName, patientAge, patientPhone, reason } = req.body;
  const d = await Doctor.findById(doctor);
  if (!d) { res.status(404); throw new Error('Doctor not found'); }
  if (new Date(date + 'T23:59:59') < new Date()) { res.status(400); throw new Error('Date is in the past'); }
  const day = new Date(date + 'T00:00:00').getDay();
  if (!d.availability.find((a) => a.day === day)?.slots.includes(slot)) { res.status(400); throw new Error('Doctor is not available at that time'); }
  if (date === todayStr() && toMin(slot) <= toMin(hhmm())) { res.status(400); throw new Error('That time has already passed. Choose a later slot.'); }
  const a = await Appointment.create({ patient: req.user._id, doctor, department: d.department, date, slot, patientName, patientAge, patientPhone, reason });
  res.status(201).json(await a.populate('doctor department'));
});

// Queue info for one accepted appointment: patients ahead + a live estimated time.
async function withQueue(a) {
  const o = a.toObject ? a.toObject() : a;
  if (!['accepted', 'in_consultation'].includes(o.status) || !o.token) return o;
  const docId = o.doctor?._id || o.doctor;
  const ahead = await Appointment.countDocuments({ doctor: docId, date: o.date, status: { $in: ['accepted', 'in_consultation'] }, token: { $lt: o.token } });
  o.patientsAhead = ahead;
  if (o.date === todayStr() && o.status === 'accepted') {
    const live = toMin(hhmm()) + ahead * AVG_CONSULT_MIN;
    o.liveEstimate = fromMin(Math.max(live, toMin(o.estimatedTime || o.slot)));
  }
  return o;
}
export const mine = wrap(async (req, res) => {
  const list = await Appointment.find({ patient: req.user._id }).populate('doctor department').sort('-date -createdAt');
  res.json(await Promise.all(list.map(withQueue)));
});
export const cancel = wrap(async (req, res) => {
  const a = await Appointment.findById(req.params.id);
  if (!a || String(a.patient) !== String(req.user._id)) { res.status(404); throw new Error('Appointment not found'); }
  if (!['pending', 'accepted'].includes(a.status)) { res.status(400); throw new Error('This appointment can no longer be cancelled'); }
  a.status = 'cancelled'; a.active = false; await a.save(); res.json(a);
});

// ---------- Doctor portal ----------
const myDoctor = async (req, res) => {
  const d = await Doctor.findOne({ user: req.user._id });
  if (!d) { res.status(404); throw new Error('Doctor profile not found'); }
  return d;
};
export const doctorAppointments = wrap(async (req, res) => {
  const d = await Doctor.findOne({ user: req.user._id });
  const { date, status } = req.query, f = { doctor: d?._id };
  if (date) f.date = date; if (status) f.status = status;
  res.json(d ? await Appointment.find(f).populate('patient', 'name email phone gender').sort('date token slot') : []);
});

// 2) DOCTOR accepts -> token + estimated time are generated. Or rejects with a reason.
export const decide = wrap(async (req, res) => {
  const d = await myDoctor(req, res);
  const { action, estimatedTime, note } = req.body;
  const a = await Appointment.findById(req.params.id);
  if (!a || String(a.doctor) !== String(d._id)) { res.status(404); throw new Error('Appointment not found'); }
  if (a.status !== 'pending') { res.status(400); throw new Error('This request has already been handled'); }
  if (action === 'accept') {
    if (estimatedTime && !/^\d{2}:\d{2}$/.test(estimatedTime)) { res.status(400); throw new Error('Estimated time must be HH:MM'); }
    const last = await Appointment.findOne({ doctor: d._id, date: a.date, token: { $exists: true } }).sort('-token');
    a.token = (last?.token || 0) + 1;
    a.estimatedTime = estimatedTime || a.slot;
    a.status = 'accepted';
  } else if (action === 'reject') {
    a.status = 'rejected'; a.active = false;
  } else { res.status(400); throw new Error('action must be accept or reject'); }
  a.decisionNote = note || ''; a.decidedAt = new Date();
  await a.save(); res.json(a);
});

// Queue actions: start / complete / no-show / change estimated time
const TRANSITIONS = { accepted: ['in_consultation', 'no_show', 'cancelled'], in_consultation: ['completed'], pending: [] };
export const setStatus = wrap(async (req, res) => {
  const { status, notes, estimatedTime } = req.body;
  const a = await Appointment.findById(req.params.id).populate('doctor');
  if (!a) { res.status(404); throw new Error('Appointment not found'); }
  const isAdmin = req.user.role === 'admin';
  if (!isAdmin && String(a.doctor.user) !== String(req.user._id)) { res.status(403); throw new Error('Not your appointment'); }
  if (estimatedTime && /^\d{2}:\d{2}$/.test(estimatedTime)) a.estimatedTime = estimatedTime;
  if (status && status !== a.status) {
    if (!isAdmin && !TRANSITIONS[a.status]?.includes(status)) { res.status(400); throw new Error(`Cannot change from ${a.status} to ${status}`); }
    if (!['pending', 'accepted', 'in_consultation', 'completed', 'rejected', 'cancelled', 'no_show'].includes(status)) { res.status(400); throw new Error('Invalid status'); }
    a.status = status; a.active = !['cancelled', 'rejected', 'no_show'].includes(status);
    if (status === 'in_consultation') a.startedAt = new Date();
    if (status === 'completed') a.completedAt = new Date();
  }
  if (notes !== undefined) a.notes = notes;
  await a.save(); res.json(a);
});

// Doctor dashboard numbers + chart data
export const doctorStats = wrap(async (req, res) => {
  const d = await myDoctor(req, res);
  const t = todayStr();
  const all = await Appointment.find({ doctor: d._id }).select('date status patient completedAt startedAt');
  const count = (f) => all.filter(f).length;
  const todays = all.filter((a) => a.date === t);
  const days = [...Array(14)].map((_, i) => { const x = new Date(); x.setDate(x.getDate() - 13 + i); return new Date(x.getTime() - x.getTimezoneOffset() * 60000).toISOString().slice(0, 10); });
  const trend = days.map((day) => ({ date: day, total: count((a) => a.date === day && LIVE.includes(a.status)), completed: count((a) => a.date === day && a.status === 'completed') }));
  const byStatus = ['pending', 'accepted', 'in_consultation', 'completed', 'rejected', 'cancelled', 'no_show'].map((s) => ({ status: s, count: count((a) => a.status === s) }));
  const done = all.filter((a) => a.startedAt && a.completedAt).map((a) => (a.completedAt - a.startedAt) / 60000).filter((m) => m > 0 && m < 240);
  res.json({
    today: { total: todays.filter((a) => LIVE.includes(a.status)).length, pending: todays.filter((a) => a.status === 'pending').length, waiting: todays.filter((a) => a.status === 'accepted').length, inConsultation: todays.filter((a) => a.status === 'in_consultation').length, completed: todays.filter((a) => a.status === 'completed').length, rejected: todays.filter((a) => a.status === 'rejected').length },
    pendingAll: count((a) => a.status === 'pending'), upcoming: count((a) => a.date > t && ['pending', 'accepted'].includes(a.status)),
    totalPatients: new Set(all.filter((a) => a.status === 'completed').map((a) => String(a.patient))).size,
    totalCompleted: count((a) => a.status === 'completed'),
    avgConsultMinutes: done.length ? Math.round(done.reduce((x, y) => x + y, 0) / done.length) : null,
    trend, byStatus,
  });
});

// Medical records
export const addRecord = wrap(async (req, res) => {
  const d = await Doctor.findOne({ user: req.user._id });
  const { appointment, diagnosis, notes, prescriptions } = req.body;
  const ap = await Appointment.findById(appointment);
  if (!d || !ap || String(ap.doctor) !== String(d._id)) { res.status(403); throw new Error('Not your appointment'); }
  res.status(201).json(await MedicalRecord.create({ patient: ap.patient, appointment: ap._id, doctor: d._id, diagnosis, notes, prescriptions: (prescriptions || []).filter((p) => p.medicine) }));
});
export const myRecords = wrap(async (req, res) =>
  res.json(await MedicalRecord.find({ patient: req.user._id }).populate('doctor', 'name').sort('-createdAt')));
