import { User, Doctor, Appointment, Department, Inquiry } from '../models/index.js';
import { wrap } from '../middleware/index.js';

export const stats = wrap(async (req, res) => {
  const [patients, doctors, appointments, departments, byStatus, perDay] = await Promise.all([
    User.countDocuments({ role: 'patient' }), Doctor.countDocuments(), Appointment.countDocuments(), Department.countDocuments(),
    Appointment.aggregate([{ $group: { _id: '$status', count: { $sum: 1 } } }]),
    Appointment.aggregate([{ $group: { _id: '$date', count: { $sum: 1 } } }, { $sort: { _id: -1 } }, { $limit: 14 }]),
  ]);
  res.json({ patients, doctors, appointments, departments, byStatus, perDay: perDay.reverse() });
});
export const listPatients = wrap(async (req, res) => res.json(await User.find({ role: 'patient' }).sort('-createdAt')));
export const deleteUser = wrap(async (req, res) => { await User.deleteOne({ _id: req.params.id, role: { $ne: 'admin' } }); res.json({ ok: true }); });
export const allAppointments = wrap(async (req, res) =>
  res.json(await Appointment.find().populate('doctor department').populate('patient', 'name email').sort('-createdAt')));
// Creating a doctor also creates the doctor's login account
export const createDoctor = wrap(async (req, res) => {
  const { email, password, ...rest } = req.body;
  const DEF=[1,2,3,4,5,6].map((day)=>({day,slots:['09:00','09:30','10:00','10:30','11:00','16:00','16:30','17:00']}));
  const user = await User.create({ name: rest.name, email, password: password || 'Doctor@123', role: 'doctor' });
  res.status(201).json(await Doctor.create({ availability: DEF, ...rest, user: user._id }));
});
export const deleteAppointment = wrap(async (req, res) => { await Appointment.findByIdAndDelete(req.params.id); res.json({ ok: true }); });
export const inquiries = wrap(async (req, res) => res.json(await Inquiry.find().sort('-createdAt')));
