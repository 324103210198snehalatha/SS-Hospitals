import 'dotenv/config';
import express from 'express';
import cors from 'cors';
import morgan from 'morgan';
import connectDB from './config/db.js';
import routes from './routes/index.js';
import { notFound, errorHandler } from './middleware/index.js';

if (!process.env.JWT_SECRET || !process.env.MONGO_URI) {
  console.error('Missing server/.env — run `cp .env.example .env` inside the server folder (needs MONGO_URI and JWT_SECRET).');
  process.exit(1);
}
const app = express();
const allowed = (process.env.CLIENT_URL || 'http://localhost:5173').split(',').map((x) => x.trim());
app.use(cors({ origin: (origin, cb) => cb(null, !origin || allowed.includes(origin) || /^https?:\/\/(localhost|127\.0\.0\.1)(:\d+)?$/.test(origin)) }));
app.use(express.json());
app.use(morgan('dev'));
app.get('/api/health', (q, s) => s.json({ status: 'ok' }));
app.use('/api', routes);
app.use(notFound);
app.use(errorHandler);

connectDB().then(() => app.listen(process.env.PORT || 5000, () => console.log('SS Hospitals API running')))
  .catch((e) => { console.error(e.message); process.exit(1); });
